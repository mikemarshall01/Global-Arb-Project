# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Thu Nov 30 09:20:44 2017)---
import pandas as pd
import numpy as np
df_clipper= pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
df_reuters = pd.read_excel('L:\TRADING\ANALYSIS\FIXTURES\REUTERS.xlsx', sheetname=1, header=0)
df_clipper=df_clipper['Vessel IMO'].unique()
df_clipper=df_clipper['IMO'].unique()
df_clipper=df_clipper['imo'].unique()
df_clipper= pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
df_clipper=df_clipper[df_clipper['Vessel IMO'].unique()]
df_clipper=df_clipper[df_clipper['imo'].unique()]
df_clipper['imo'].unique()
dary=df_clipper['imo'].unique()
dfFiltered=df_clipper[dary]
%clear
ref_test_data = pd.read_excel('M:\test_datra_for_ref_resample.xlsx')
ref_test_data.head()
ref_test_data = pd.read_excel('M:\test_datra_for_ref_resample.xlsx', sheetname=0, header=0)
ref_test_data.head()
ref_test_data = pd.read_excel('M:\test_data_for_ref_resample.xlsx', sheetname=0, header=0)
ref_test_data.head()

## ---(Thu Nov 30 10:43:41 2017)---
import pandas as pd
import numpy as np

ref_data = pd.read_excel('M:\test_data_for_ref_resample.xlsx')
import pandas as pd
import numpy as np

ref_data = pd.read_excel('M:\test_data_for_ref_resample.xlsx')
runfile('C:/Users/mima/.spyder-py3/temp.py', wdir='C:/Users/mima/.spyder-py3')
import pandas as pd
import numpy as np

ref_data = pd.read_excel('M://test_data_for_ref_resample.xlsx', sheetname=0, header=0)
ref_dat
num_days = ref_data.iloc[0, 5]
num_days = ref_data.iloc[0, 5:7]
num_days = ref_data.iloc[0, 4:6]
num_days_diff = num_days[1] - num_days[0]
num_days_diff
start_date = ref_data.iloc[0,5]
end_date = ref_data.iloc[0,6]
start_date = ref_data.iloc[0,4]
end_date = ref_data.iloc[0,5]
cap_offline = ref_data.iloc[0,6]

num_days_offline = end_date - start_date
runfile('C:/Users/mima/.spyder-py3/temp.py', wdir='C:/Users/mima/.spyder-py3')
ref_data['Diff']=ref_data['end_date']-ref_data['start_date']
ref_data['Diff']=ref_data['END_DATE']-ref_data['Start_Date']
type(ref_data['Diff'])
days_list=[x for x range(start_Date,end_Date)]
days_list=[x for x in range(start_Date,end_Date)]
days_list=[x for x in range(start_date,end_date)]
days_list=[x for x in range(num_days_offline.days +1)]
days_list=[start_date + timedelta(days=i) for x in range(num_days_offline.days +1)]
days_list=[start_date + timedelta(days=x) for x in range(num_days_offline.days +1)]
pd_index_start_date = datetime(2005, 1, 1)
pd_index_start_date = datetime(2020, 12, 1)

days_list=[start_date + timedelta(days=x) for x in range(num_days_offline.days +1)]
pd_index_end_date = datetime(2020, 12, 1)
pd_index_start_date = datetime(2005, 1, 1)
total_time_period = pd_index_end_date - pd_index_start_date
days_list=[pd_index_start_date + timedelta(days=x) for x in range(total_time_period.days +1)]
pd_index_days_list=[pd_index_start_date + timedelta(days=x) for x in range(total_time_period.days +1)]
maintenance_framework = pd.DataFrame(0, index= pd_index_days_list)
maintenance_framework = pd.DataFrame(data=None, index= pd_index_days_list)
test_dataframe = pd.DataFrame(data=250, index= pd_index_days_list)
test_dataframe = pd.DataFrame(data=int(250), index= pd_index_days_list)
test_dataframe = pd.DataFrame(data=None, index= pd_index_days_list)
test_dataframe['REF'] = 250
num_days_offline = end_date - start_date
### then create time series index for duration period
ref_test_index=[start_date + timedelta(days=x) 
        for x in range(num_days_offline.days +1)]

### then create dataframe for this index
ref_test_dataframe  = pd.DataFrame(data=None, index=ref_test_index)
ref_test_dataframe['Refinery'] = ref_data.loc[0,'CAP_OFFLINE']

import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)


dtrange = pd.date_range(begin, end)
p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)
d = df.index.day - np.clip((df.index.day-1) // 10, 0, 2)*10 - 1
date = df.index.values - np.array(d, dtype="timedelta64[D]")
df.groupby(date).mean()
d = df.index.day
print(d)
print(d-1)
print((d-1) // 10)
print(((d-1) // 10), 0, 2)
print(np.clip((d-1) // 10), 0, 2)
d = df.index.day
print(d)
print(d-1)
print((d-1) // 10)
print(np.clip((d-1) // 10, 0, 2))
print(np.clip((d-1) // 10, 0, 2)*10)
print(np.clip((d-1) // 10, 0, 2)*10-1)
print(df.index.day - np.clip((d-1) // 10, 0, 2)*10-1)
print(df.index.day - np.clip((df.index.day-1) // 10, 0, 2)*10-1)
d = df.index.day - np.clip((df.index.day-1) // 10, 0, 2)*10 - 1
print(df.index.values)
print(np.array(d, dtype = "timedelta[D]"))
print(np.array(d, dtype = "timedelta64[D]"))
print(df.index.values - np.array(d, dtype = "timedelta64[D]"))
decades = df.index.values - np.array(d, dtype = "timedelta64[D]")
d = df.index.day - np.clip((df.index.day-1) // 10, 0, 2)*10 - 1
date = df.index.values - np.array(d, dtype="timedelta64[D]")
df.groupby(date).mean()
for index, row in ref_data.iterrows():
    print  row['COUNTRY']
for index, row in ref_data.iterrows():
    print row['COUNTRY']
for index, row in ref_data.iterrows():
    print(row['COUNTRY'])
OUTAGE_TYPE
for index, row in ref_data.iterrows():
    print(row['OUTAGE_TYPE'])
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    #num_days_offline = end_date - start_date
    ref_test_df = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df[str(row['REFINERY'])] = ref_test_df['CAP_OFFLINE']
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    #num_days_offline = end_date - start_date
    ref_test_df = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df[row['REFINERY']] = ref_test_df['CAP_OFFLINE']
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    #num_days_offline = end_date - start_date
    ref_test_df = pd.date_range(start=start_date, end=end_date, freq='D')
    name = row['REFINERY']
    ref_test_df[name] = ref_test_df['CAP_OFFLINE']
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    #num_days_offline = end_date - start_date
    ref_test_df = pd.date_range(start=start_date, end=end_date, freq='D')
    name = row['REFINERY']
    ref_test_df[name] = row['CAP_OFFLINE']
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework.add(ref_test_df, fill_value=0)
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
    maintenance_framework = maintenance_framework.sum(axis=1).to_frame()
    
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
   #maintenance_framework = maintenance_framework.sum(axis=1).to_frame()
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
    maintenance_framework = maintenance_framework.sum(axis=1)
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
    maintenance_framework = maintenance_framework.sum(axis=1).to_frame()
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
    maintenance_framework = maintenance_framework.sum(axis=1).to_frame(name)
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//NORTH AMERICA.xlsm",
                         sheetname=0, header=0, usecols = "A:M")
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
    maintenance_framework = maintenance_framework.sum(axis=1).to_frame()
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
    maintenance_framework = maintenance_framework.sum(axis=1).to_frame(name)
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)
    ref_test_df[name] = row['CAP_OFFLINE']
    maintenance_framework = pd.concat([ref_test_df, maintenance_framework], axis=1)
    #maintenance_framework = maintenance_framework.sum(axis=1).to_frame(name)
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
maintenance_framework = pd.DataFrame(data=None, index= pd_index_days_list)
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
maintenance_framework = pd.DataFrame(data=None, index= pd_index_days_list)
index=1
row=
#ref_data = ref_data[(ref_data['UNIT_NAME'] == 'CRUDE #1') & ((ref_data['REFINERY'] == 'ALLIANCE/BELLE CHASE')
ref_data['Start_Date'].apply(lambda x : x.datetime() in ref_data['Start_Date'])
ref_data['Start_Date'].apply(lambda x : x.date() in ref_data['Start_Date'])
ref_data = pd.read_excel("M://test_data_for_ref_resample.xlsx", sheetname=0, header=0,parse_dates=False)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

#ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//NORTH AMERICA.xlsm",
 #                        sheetname=0, header=0)

ref_data = pd.read_excel("M://test_data_for_ref_resample.xlsx", sheetname=0, header=0,parse_dates=False)
end_date = row['END_DATE']
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']

for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=None, index=date_range)

ref_list=ref_data['REFINERY'].unique()
ref_list=pd.Series(ref_data['REFINERY'].unique())
maintenance_framework = pd.DataFrame(data=None, index= pd_index_days_list, columns=ref_list)
pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

#ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//NORTH AMERICA.xlsm",
 #                        sheetname=0, header=0)

ref_data = pd.read_excel("M://test_data_for_ref_resample.xlsx", sheetname=0, header=0)
ref_data['Start_Date'].apply(lambda x : x.date() in ref_data['Start_Date'])
#ref_data = ref_data[(ref_data['UNIT_NAME'] == 'CRUDE #1') & ((ref_data['REFINERY'] == 'ALLIANCE/BELLE CHASE')
#                     | (ref_data['REFINERY'] == 'ARDMORE'))]

ref_data = ref_data[(ref_data['UNIT_NAME'] == 'CRUDE #1')]

### Set start and end dates for the entire dataframe
pd_index_start_date = datetime(2005, 1, 1)
pd_index_end_date = datetime(2020, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())
maintenance_framework = pd.DataFrame(data=None, index= pd_index_days_list, columns=ref_list)
maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(data=row['CAP_OFFLINE'], index=date_range, columns= row['REFINERY'])

ref_test_df = pd.DataFrame(0, index=date_range, columns= row['REFINERY'])
row
date_range
ref_test_df = pd.DataFrame(0, index=date_range, columns= row['REFINERY'])
ref_test_df = pd.DataFrame(0, index=date_range, columns= list(row['REFINERY']))
ref_test_df = pd.DataFrame(0, index=date_range, columns= [row['REFINERY']])
list(row['REFINERY'])
ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
maintenance_framework.loc[ref_test_df.index,row['REFINERY']]=ref_test_df[ref_test_df.index,row['REFINERY']]
maintenance_framework.loc[date_range,row['REFINERY']]=ref_test_df[date_range,row['REFINERY']]
maintenance_framework.loc[date_range,name]=ref_test_df[date_range,name]
maintenance_framework.loc[ref_test_df.index,name]=ref_test_df.loc[ref_test_df.index,name]
maintenance_framework.to_excel(test_path+'main.xlsx')
test_path='C:/Python Proj/'
maintenance_framework.to_excel(test_path+'main.xlsx')
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=ref_test_df.loc[ref_test_df.index,name]

maintenance_framework.to_excel(test_path+'main.xlsx')
for index, row in ref_data.iterrows():
    end_date = row['END_DATE']
    start_date = row['Start_Date']
    name = row['REFINERY']
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]

maintenance_framework.to_excel(test_path+'main.xlsx')
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
maintenance_framework.to_excel(test_path+'main.xlsx')
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
print(d)
print(date)
maintenance_framework.groupby(date).mean()  
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
print(maintenance_framework_week)
print(maintenance_framework_weekly)
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
end_date = [x for x in row['END_DATE'] if row['END_DATE'] > date(2005,1,1)]
runfile('C:/Users/mima/.spyder-py3/refinery_database_tester.py', wdir='C:/Users/mima/.spyder-py3')
runfile('C:/Users/mima/.spyder-py3/refinery_database_tworking.py', wdir='C:/Users/mima/.spyder-py3')
file = pd.read_excel('L:/TRADING/ANALYSIS/PRICES/CXL Prices.xlsx', sheetname=0)
print(file.head())
import pandas as pd

file = pd.read_excel('L:/TRADING/ANALYSIS/PRICES/CXL Prices.xlsx', sheetname=0)
print(file.head())
file.tail(5)
file.tail(50)
unique_name_list = file['name'].unique()
unique_name_list = pd.Series(file['name'].unique())
filter = file[file['name'] == 'P Diesel 10ppm FOB RDAM FWD']
from datetime import date

filter = file[(file['name'] == 'P Diesel 10ppm FOB RDAM FWD') &
              (file['asof_date' == date(2016,1,1)])]
filter = file[(file['name'] == 'P Diesel 10ppm FOB RDAM FWD') &
              (file['asof_date' == date(2016,4,1)])]
filter = file[(file['name'] == 'P Diesel 10ppm FOB RDAM FWD') &
              (file['asof_date' == datetime(2016,4,1)])]
from datetime import datetime

filter = file[(file['name'] == 'P Diesel 10ppm FOB RDAM FWD') &
              (file['asof_date' == datetime(2016,4,1)])]
filter = file[(file['name'] == 'P Diesel 10ppm FOB RDAM FWD') &
              (file['asof_date'] == datetime(2016,4,1))]
runfile('C:/Users/mima/.spyder-py3/refinery_database_tworking.py', wdir='C:/Users/mima/.spyder-py3')
runfile('C:/Users/mima/.spyder-py3/refinery_database_tworking.py', wdir='C:/Users/mima/.spyder-py3')
runfile('C:/Users/mima/.spyder-py3/KALUNBORG.py', wdir='C:/Users/mima/.spyder-py3')
ref_data = ref_data[(ref_data['REFINERY'] == 'KALUNDBORG') & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['REFINERY'] == 'KALUNDBORG') & (ref_data[5] > date(2017,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
ref_data = ref_data[(ref_data['REFINERY'] == 'KALUNDBORG') & (ref_data['START_DATE'] > date(2017,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['REFINERY'] == 'KALUNDBORG') & (ref_data['START_DATE'] > datetime(2017,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]

## ---(Tue Dec  5 10:46:28 2017)---
file = pd.read_excel('L:/TRADING/ANALYSIS/PRICES/CXL Prices.xlsx', sheetname=0)
print(file.head())

unique_name_list = pd.Series(file['name'].unique())

from datetime import datetime

filter = file[(file['name'] == 'P Diesel 10ppm FOB RDAM FWD') &
              (file['asof_date'] == datetime(2016,4,1))]
import pandas as pd

file = pd.read_excel('L:/TRADING/ANALYSIS/PRICES/CXL Prices.xlsx', sheetname=0)
print(file.head())

unique_name_list = pd.Series(file['name'].unique())

from datetime import datetime

filter = file[(file['name'] == 'P Diesel 10ppm FOB RDAM FWD') &
              (file['asof_date'] == datetime(2016,4,1))]
runfile('C:/Users/mima/.spyder-py3/cxl experiment.py', wdir='C:/Users/mima/.spyder-py3')
import sqlite3
import pyodbc
cnxn = pyodbc.connect(
        r'Driver={SQL Server Native Client 11.0};'
        r'Server=.\STCHGS126;'
        r'UID=gami;'
        r'Database=myDB;'
        r'Trusted_Connection=yes;'
        r'WSID=STUKLW05;'
        r'DATABASE=STG_Price;'
        r'ServerSPN=STG_Price;')
cursor = cnxn.cursor()
cursor.execute("""SELECT STUK_Prices.curve_num, STUK_Prices.name, STUK_Prices.asof_date, STUK_Prices.maturity_date, STUK_Prices.maturity_type, STUK_Prices.price
FROM STG_Price.dbo.STUK_Prices STUK_Prices
WHERE STUK_Prices.asof_date >= '1-jan-2010'""")
while 1:
    row = cursor.fetchone()
    if not row:
        break
    print(row.LastName)

cnxn.close()


debugfile('C:/Users/mima/.spyder-py3/SQL Connection Attempt.py', wdir='C:/Users/mima/.spyder-py3')
runfile('C:/Users/mima/.spyder-py3/SQL Connection Attempt.py', wdir='C:/Users/mima/.spyder-py3')
import pyodbc
cnxn = pyodbc.connect(
        '''Driver={SQL Server Native Client 11.0};
        Server=.\STCHGS126;
        UID=gami;
        Trusted_Connection=yes;
        APP=Microsoft Office 2010;
        WSID=STUKLW05;
        DATABASE=STG_Price;
        ServerSPN=STG_Price''')
cursor = cnxn.cursor()
import pyodbc

cnxn = pyodbc.connect(
        '''Driver={SQL Server Native Client 11.0};
        Server=.\STCHGS126;
        UID=gami;
        Trusted_Connection=yes;
        APP=Microsoft Office 2010;
        WSID=STUKLW05;
        DATABASE=STG_Price;
        ServerSPN=STG_Price''')
cursor = cnxn.cursor()
import pypyodbc
connection = pypyodbc.connect('Driver={SQL Server};'
 'Server=STCHGS126;'
 'Database=STG_Price;'
 'uid=gami')
connection.close()
import pyodbc
connection = pypyodbc.connect('Driver={SQL Server};'
 'Server=STCHGS126;'
 'Database=STG_Price;'
 'uid=gami')
connection.close()
import pyodbc
connection = pyodbc.connect('Driver={SQL Server};'
 'Server=STCHGS126;'
 'Database=STG_Price;'
 'uid=gami')
connection.close()
import pyodbc
cnxn = pyodbc.connect(
        '''Driver={SQL Server Native Client 11.0};
        Server=STCHGS126;
        UID=gami;
        Trusted_Connection=yes;
        WSID=STUKLW05;
        DATABASE=STG_Price;
        ServerSPN=STG_Price''')
cursor = cnxn.cursor()
cursor.execute("""SELECT STUK_Prices.curve_num, STUK_Prices.name, STUK_Prices.asof_date, STUK_Prices.maturity_date, STUK_Prices.maturity_type, STUK_Prices.price
FROM STG_Price.dbo.STUK_Prices STUK_Prices
WHERE STUK_Prices.asof_date >= '1-jan-2010'""")
while 1:
    row = cursor.fetchone()
    if not row:
        break
    print(row.LastName)

cnxn.close()
import pyodbc
cnxn = pyodbc.connect(
        '''Driver={SQL Server Native Client 11.0};
        Server=STCHGS126;
        UID=gami;
        Trusted_Connection=yes;
        WSID=STUKLW05;
        DATABASE=STG_Price;
        ServerSPN=STG_Price''')
cursor = cnxn.cursor()
cursor.execute("""SELECT STUK_Prices.curve_num, STUK_Prices.name, STUK_Prices.asof_date, STUK_Prices.maturity_date, STUK_Prices.maturity_type, STUK_Prices.price
FROM STG_Price.dbo.STUK_Prices STUK_Prices
WHERE STUK_Prices.asof_date >= '1-jan-2010'""")
while 1:
    row = cursor.fetchone()
    if not row:
        break
    print(row.LastName)

cnxn.close()
while 1:
    row = cursor.fetchone()
    if not row:
        break
    print(row)

cnxn.close()

import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 
ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] == datetime(2018,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]

pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)

for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = date(2005,1,1)
filtered_end_date = date(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]

#maintenance_framework.to_excel(test_path+'daily.xlsx')
#maintenance_framework_month.to_excel(test_path+'monthly.xlsx')
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] == datetime(2018,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)
for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = date(2005,1,1)
filtered_end_date = date(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]
for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]


filtered_start_date = date(2005,1,1)
filtered_end_date = date(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()
filtered_start_date = date(2005,1,1)
filtered_end_date = date(2020,12,1)    
filtered_start_date = date(2005,1,1)
for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]

filtered_start_date = date(2005,1,1)
filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)   
filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]
filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  
import pandas as pd
import numpy as np
from datetime import datetime, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] == datetime(2018,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)

for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]
filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1) 
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  
print(date)
filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
print(d)
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
print(date)
for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]

import pandas as pd
import numpy as np
from datetime import datetime, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)
ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] == datetime(2018,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] == datetime(2018,1,1,0,0,0)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] > datetime(2018,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)
ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] > datetime(2018,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)

for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]
"""
Created on Mon Dec  4 10:07:04 2017

@author: mima
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] > datetime(2018,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]

pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)

for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]

test_path='L:/TRADING/ANALYSIS/Python/MIMA/RefineryDatabaseChecks/'

maintenance_framework.to_excel(test_path+'daily.xlsx')
maintenance_framework_month.to_excel(test_path+'monthly.xlsx')
maintenance_framework_week.to_excel(test_path+'weekly.xlsx')
maintenance_framework_decade.to_excel(test_path+'decade.xlsx')
import pandas as pd
import numpy as np
from datetime import datetime, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] > datetime(2017,12,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]

pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)

for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]

test_path='L:/TRADING/ANALYSIS/Python/MIMA/RefineryDatabaseChecks/'

maintenance_framework.to_excel(test_path+'daily.xlsx')
maintenance_framework_month.to_excel(test_path+'monthly.xlsx')
maintenance_framework_week.to_excel(test_path+'weekly.xlsx')
maintenance_framework_decade.to_excel(test_path+'decade.xlsx')
import pandas as pd
import numpy as np
from datetime import datetime, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] > datetime(2017,12,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]

pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)

for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]

test_path='L:/TRADING/ANALYSIS/Python/MIMA/RefineryDatabaseChecks/'

maintenance_framework.to_excel(test_path+'daily.xlsx')
maintenance_framework_month.to_excel(test_path+'monthly.xlsx')
maintenance_framework_week.to_excel(test_path+'weekly.xlsx')
maintenance_framework_decade.to_excel(test_path+'decade.xlsx')
ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)
import pandas as pd
import numpy as np
from datetime import datetime, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] > datetime(2017,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]
import pandas as pd
import numpy as np
from datetime import datetime, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//REST of WORLD.xlsm",
                        sheetname=0, header=0)

ref_data = ref_data[(ref_data['COUNTRY'] == 'RUSSIAN FEDERATION') & (ref_data['START_DATE'] > datetime(2017,1,1)) & ((ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2'))]

pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')

ref_list=pd.Series(ref_data['REFINERY'].unique())

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)

for index, row in ref_data.iterrows():
    end_date = row[5]
    start_date = row[4]
    name = row[1]
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]



filtered_start_date = datetime(2005,1,1)
filtered_end_date = datetime(2020,12,1)    
d = maintenance_framework.index.day - np.clip((maintenance_framework.index.day-1) // 10, 0, 2)*10 - 1
date = maintenance_framework.index.values - np.array(d, dtype="timedelta64[D]")
maintenance_framework_decade = maintenance_framework.groupby(date).mean()  

maintenance_framework_month = maintenance_framework.resample('M', convention = 'start').mean()
maintenance_framework_week =  maintenance_framework.resample('W', convention = 'start').mean()

maintenance_framework_month = maintenance_framework_month.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_week = maintenance_framework_week.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework_decade = maintenance_framework_decade.loc[filtered_start_date:filtered_end_date,:]
maintenance_framework = maintenance_framework.loc[filtered_start_date:filtered_end_date,:]

test_path='L:/TRADING/ANALYSIS/Python/MIMA/RefineryDatabaseChecks/'

maintenance_framework.to_excel(test_path+'daily.xlsx')
maintenance_framework_month.to_excel(test_path+'monthly.xlsx')
maintenance_framework_week.to_excel(test_path+'weekly.xlsx')
maintenance_framework_decade.to_excel(test_path+'decade.xlsx')
runfile('C:/Users/mima/.spyder-py3/refinery_database_tworking.py', wdir='C:/Users/mima/.spyder-py3')
import pandas as pd

latam1020 = pd.read_csv("C:/Users/mima/Desktop/latam 2010.csv")
import pandas as pd

latam1020 = pd.read_csv("C:/Users/mima/Desktop/latam 2010.csv")
latam1027 = pd.read_csv("C:/Users/mima/Desktop/latam 2710.csv")

## ---(Fri Dec  8 14:14:43 2017)---
conn = sqlite3.connect('L:/TRADING/ANALYSIS/Python/MIMA/TestAndTextbooks/tysql.sqlite') 
"""

import sqlite3

conn = sqlite3.connect('L:/TRADING/ANALYSIS/Python/MIMA/TestAndTextbooks/tysql.sqlite') 
import sqlite3

conn = sqlite3.connect('tysql.sqlite') 
cur = conn.cursor()
c.execute('''

CREATE TABLE Products
(
  prod_id    char(10)      NOT NULL ,
  vend_id    char(10)      NOT NULL ,
  prod_name  char(255)     NOT NULL ,
  prod_price decimal(8,2)  NOT NULL ,
  prod_desc  varchar(1000) NULL 
);

''')
c = conn.cursor()
c.execute('''

CREATE TABLE Products
(
  prod_id    char(10)      NOT NULL ,
  vend_id    char(10)      NOT NULL ,
  prod_name  char(255)     NOT NULL ,
  prod_price decimal(8,2)  NOT NULL ,
  prod_desc  varchar(1000) NULL 
);

''')
conn = sqlite3.connect('tysql.sqlite') 
c = conn.cursor()
c.execute('''

CREATE TABLE Products
(
  prod_id    char(10)      NOT NULL ,
  vend_id    char(10)      NOT NULL ,
  prod_name  char(255)     NOT NULL ,
  prod_price decimal(8,2)  NOT NULL ,
  prod_desc  varchar(1000) NULL 
);

''')
import pypdf2
"""
 import pypdf2
import pypdf2

## ---(Mon Dec 11 20:26:34 2017)---
import pypdf2

pip install pypdf2
import pandas as pd
import numpy as np
begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)
dtrange = pd.date_range(begin, end)
p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10
df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)
dfindexday = df.index.day
d = df.index.day - np.clip((df.index.day-1) // 10, 0, 2)*10 - 1
date = df.index.values - np.array(d, dtype="timedelta64[D]")
print(df.index.day)
print(df.index.day-1)
print((df.index.day-1) // 10)
print(np.clip((df.index.day-1) // 10, 0, 2))
print(np.clip((df.index.day-1) // 10, 0, 2))*10
%clear
import pandas as pd
import numpy as np
begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10
df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)
print(df.index.day)
print(df.index.day-1)
print((df.index.day-1) // 10)
print(np.clip((df.index.day-1) // 10, 0, 2))
print((np.clip((df.index.day-1) // 10, 0, 2))*10)
print((np.clip((df.index.day-1) // 10, 0, 2))*10-1)
print(df.index.values)
print(np.array(d, dtype="timedelta64[D]"))
d = df.index.day - np.clip((df.index.day-1) // 10, 0, 2)*10 - 1
print(np.array(d, dtype="timedelta64[D]"))
%clear
print(df.index.day)
print(df.index.day-1)
print((df.index.day-1) // 10)
print(df.index.day -1 -(np.clip((df.index.day-1) // 10, 0, 2))*10)
d = df.index.day -1 - np.clip((df.index.day-1) // 10, 0, 2)*10
print(df.index.values)
print(np.array(d, dtype="timedelta64[D]"))
print(df.index.values - np.array(d, dtype="timedelta64[D]"))
df.groupby(date).mean()

## ---(Wed Dec 20 11:46:02 2017)---
import pandas as pd
import numpy as np

file = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")

MappingData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Mapping")
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")

UniqueMappingDataLordPorts = MappingData['Load Port'].unique()
UniqueMappingDataLordPorts = MedFlowsData['Load Port'].unique()
print(UniqueMappingDataLordPorts)
UniqueMappingDataLordPorts = str(MedFlowsData['Load Port'].unique())
print(UniqueMappingDataLordPorts)
UniqueMappingDataLordPorts = list(MedFlowsData['Load Port'].unique())
print(UniqueMappingDataLordPorts)
UniqueMappingDataLordPorts = set(MedFlowsData['Load Port'])
print(UniqueMappingDataLordPorts)
UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))
UniqueMappingDataLordPorts = MedFlowsData['Load Port'].unique().sort()
UniqueMappingDataLordPorts = list(MedFlowsData['Load Port'].unique().sort())
UniqueMappingDataLordPorts = list(MedFlowsData['Load Port'].unique()).sort()
list(MedFlowsData['Load Port'].unique())
UniqueMappingDataLordPorts = list(MedFlowsData['Load Port'].unique())
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="Port Coords")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")
UniqueMappingDataLordPorts.iloc[1,1]
UniqueMappingDataLordPorts[1]
UniqueMedFlowsDatadPorts = list(MedFlowsData['Load Port'].unique())
x = MappingData.values.unique()
x = MappingData.columns.values.unique()
x = MappingData.columns.values
x = list(MappingData.columns.values)
UniqueMappingDataPorts = list(MappingData['TargoPortName'].unique())
import pandas as pd

file = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv",'r')
file = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
import pandas as pd

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
load_ports = list(all_clipper['load_port'].unique())
col_headers = all_clipper.columns.values
col_headers = list(all_clipper.columns.values)


load_ports = list(all_clipper['load_port'].unique())
discharge_ports = list(all_clipper['offtake_port'].unique())
port_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
col_headers = list(all_clipper.columns.values)


load_ports = list(all_clipper['load_port'].unique())
discharge_ports = list(all_clipper['offtake_port'].unique())


"""
Created on Thu Dec 21 18:08:55 2017

@author: mima
"""

import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
col_headers = list(all_clipper.columns.values)


load_ports = list(all_clipper['load_port'].unique())
discharge_ports = list(all_clipper['offtake_port'].unique())




clip_col_headers = list(all_clipper.columns.values)
targo_port_region_mappings_col_headers = list(targo_port_region_mappings.columns.values)


load_ports = list(all_clipper['load_port'].unique())
discharge_ports = list(all_clipper['offtake_port'].unique())




import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = list(all_clipper.columns.values)
targo_port_region_mappings_col_headers = list(targo_port_region_mappings.columns.values)


load_ports = list(all_clipper['load_port'].unique())
discharge_ports = list(all_clipper['offtake_port'].unique())


checked_list = pd.DataFrame()
checked_list = pd.DataFrame(targo_port_region_mappings_col_headers)
checked_list = pd.DataFrame(headers=targo_port_region_mappings_col_headers)
checked_list = pd.DataFrame(,targo_port_region_mappings_col_headers)
checked_list = pd.DataFrame(0,targo_port_region_mappings_col_headers)
checked_list = pd.DataFrame(columns=targo_port_region_mappings_col_headers)
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = list(all_clipper.columns.values)
targo_port_region_mappings_col_headers = list(targo_port_region_mappings.columns.values)

### get the unique port names that we need
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = list(all_clipper_load_ports + all_clipper_discharge_ports).unique()
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_port
all_clipper_ports = list(all_clipper_ports).unique()
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique(
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_port
all_clipper_ports = list(all_clipper_ports).unique()
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_ports = list(all_clipper_ports).unique()
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_ports = list(all_clipper_ports.unique())
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_ports = all_clipper_ports.unique()
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_ports = pd.Serie(all_clipper_ports)
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_ports = pd.Series(all_clipper_ports)
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_ports = pd.Series(all_clipper_ports).unique()
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
all_clipper_load_ports = list(all_clipper['load_port'].unique())
all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = all_clipper_load_ports + all_clipper_discharge_ports
all_clipper_ports = list(pd.Series(all_clipper_ports).unique())
targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = list(all_clipper.columns.values)
targo_port_region_mappings_col_headers = list(targo_port_region_mappings.columns.values)

### get the unique port names that we need
unique_all_clipper_load_ports = list(all_clipper['load_port'].unique())
unique_all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = unique_all_clipper_load_ports + unique_all_clipper_discharge_ports

### this means there are some load and discharge ports that are the same - investigate later
all_unique_clipper_ports = list(pd.Series(all_clipper_ports).unique())
unique_targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = list(all_clipper.columns.values)
targo_port_region_mappings_col_headers = list(targo_port_region_mappings.columns.values)

### get the unique port names that we need
unique_all_clipper_load_ports = list(all_clipper['load_port'].unique())
unique_all_clipper_discharge_ports = list(all_clipper['offtake_port'].unique())
all_clipper_ports = unique_all_clipper_load_ports + unique_all_clipper_discharge_ports

### this means there are some load and discharge ports that are the same - investigate later
all_unique_clipper_ports = list(pd.Series(all_clipper_ports).unique())
unique_targo_port_region_ports = list(targo_port_region_mappings['Clipper Port Name'].unique())
print(all_unique_clipper_ports)
clip_col_headers = all_clipper.columns.values
import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = all_clipper.columns.values
targo_port_region_mappings_col_headers = targo_port_region_mappings.columns.values

### get the unique port names that we need
unique_all_clipper_load_ports = all_clipper['load_port'].unique()
unique_all_clipper_discharge_ports = all_clipper['offtake_port'].unique()
all_clipper_ports = unique_all_clipper_load_ports + unique_all_clipper_discharge_ports

import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = all_clipper.columns.values
targo_port_region_mappings_col_headers = targo_port_region_mappings.columns.values

### get the unique port names that we need
unique_all_clipper_load_ports = all_clipper['load_port'].unique()
unique_all_clipper_discharge_ports = all_clipper['offtake_port'].unique()
all_clipper_ports = unique_all_clipper_load_ports + unique_all_clipper_discharge_ports


### get all thge unique 

### this means there are some load and discharge ports that are the same - investigate later
all_unique_clipper_ports = all_clipper_ports.unique()
unique_targo_port_region_ports = targo_port_region_mappings['Clipper Port Name'].unique()

x = all_unique_clipper_ports.tolist()
all_unique_clipper_ports = all_clipper_ports.unique()
unique_targo_port_region_ports = targo_port_region_mappings['Clipper Port Name'].unique()

import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = all_clipper.columns.values
targo_port_region_mappings_col_headers = targo_port_region_mappings.columns.values

### get the unique port names that we need
unique_all_clipper_load_ports = all_clipper['load_port'].unique()
unique_all_clipper_discharge_ports = all_clipper['offtake_port'].unique()
all_clipper_ports = unique_all_clipper_load_ports + unique_all_clipper_discharge_ports


### get all thge unique 

### this means there are some load and discharge ports that are the same - investigate later
all_unique_clipper_ports = all_clipper_ports.unique()
unique_targo_port_region_ports = targo_port_region_mappings['Clipper Port Name'].unique()
import pandas as pd
import numpy as np

all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = all_clipper.columns.values
targo_port_region_mappings_col_headers = targo_port_region_mappings.columns.values

### get the unique port names that we need
unique_all_clipper_load_ports = all_clipper['load_port'].unique()
unique_all_clipper_discharge_ports = all_clipper['offtake_port'].unique()
all_clipper_ports = unique_all_clipper_load_ports.tolist() + unique_all_clipper_discharge_ports.tolist()
import pandas as pd


all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = all_clipper.columns.values
targo_port_region_mappings_col_headers = targo_port_region_mappings.columns.values

### get the unique port names that we need
unique_all_clipper_load_ports = all_clipper['load_port'].unique()
unique_all_clipper_discharge_ports = all_clipper['offtake_port'].unique()
clip_col_headers = all_clipper.columns.values
targo_port_region_mappings_col_headers = targo_port_region_mappings.columns.values

### get the unique port names that we need
unique_all_clipper_load_ports = all_clipper['load_port'].unique
unique_all_clipper_discharge_ports = all_clipper['offtake_port'].unique
import pandas as pd


all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
targo_port_region_mappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
clip_col_headers = all_clipper.columns.values
targo_port_region_mappings_col_headers = targo_port_region_mappings.columns.values

### get the unique port names that we need
unique_all_clipper_load_ports = all_clipper['load_port'].unique
unique_all_clipper_discharge_ports = all_clipper['offtake_port'].unique
print(unique_all_clipper_load_ports)
import pandas as pd


all_clipper = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need
LoadPorts = ClipperRawData['load_port'].unique
DischargePorts = ClipperRawData['offtake_port'].unique
LoadPorts = list(ClipperRawData['load_port'].unique)
LoadPorts = list(ClipperRawData['load_port']).unique
LoadPorts = (list(ClipperRawData['load_port'])).unique
LoadPorts = ClipperRawData['load_port'].unique()
DischargePorts = ClipperRawData['offtake_port'].unique()
LoadPorts = list(ClipperRawData['load_port'].unique())
LoadPorts = list(ClipperRawData['load_port'].unique())
DischargePorts = list(ClipperRawData['offtake_port'].unique())
LoadPorts = list(ClipperRawData['load_port'].unique())
DischargePorts = list(ClipperRawData['offtake_port'].unique())

### which ports do we not have in our original list that we would want mapped
compared_port_lists = set(LoadPorts).symmetric_difference(set(DischargePorts))

print(compared_port_lists)
x = [i for i in LoadPorts not in DischargePorts]
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())
x = [i for i in LoadPorts not in DischargePorts]
LoadPorts = list(pd.Series(ClipperRawData['load_port'].unique()))
LoadPorts = ClipperRawData['load_port'].unique()
LoadPorts = LoadPorts.tolist()
DischargePorts = ClipperRawData['offtake_port'].unique()
LoadPorts = set(ClipperRawData['load_port'].unique())
LoadPorts = set(ClipperRawData['load_port'].unique())
DischargePorts = set(ClipperRawData['offtake_port'].unique())
x = [i for i in LoadPorts not in DischargePorts]
LoadPorts = list(set(ClipperRawData['load_port'].unique()))
DischargePorts = list(set(ClipperRawData['offtake_port'].unique()))
print(ClipperRawData.dtypes)
LoadPorts = ClipperRawData['load_port'].astype(str).unique()
LoadPorts = ClipperRawData['load_port'].astype(str)
LoadPorts = ClipperRawData['load_port'].unique().astype(str)
LoadPorts = ClipperRawData['load_port'].unique().astype(str)
DischargePorts = ClipperRawData['offtake_port'].unique().astype(str)
x = [i for i in LoadPorts not in DischargePorts]
x = []
x = [x.append(i) for i in LoadPorts not in DischargePorts]
LoadPorts = list(ClipperRawData['load_port'].unique().astype(str))
DischargePorts = list(ClipperRawData['offtake_port'].unique().astype(str))
LoadPorts = list(ClipperRawData['load_port'].unique())
LoadPorts.dtypes
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())
LoadPorts.dtypes
allunique=[list(LoadPorts)+list(DischargePorts)]
allunique=[LoadPorts+DischargePorts]
allunique=pd.Series(LoadPorts+DischargePorts)
allunique=LoadPorts.append(DischargePorts)
allunique=[LoadPorts.append(DischargePorts)].unique()
allunique=(LoadPorts.append(DischargePorts)).unique()
allunique=pd.Series((LoadPorts.append(DischargePorts)).unique())
dfNotIn= pd.DataFrame(PortMappings['Clipper Port Name'] not in pd.DataFrame(allunique))
x = []
x = [x.append(i) for i in PortMappings['Clipper Port Name'] not in allunique]
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique[0]
dfNotIn= allunique.loc[allunique[0] != PortMappings['Clipper Port Name']]
PortMappingsPorts = pd.DataFrame(PortMappings['Clipper Port Name'])
check = pd.merge(allunique,PortMappingsPort, indicator=True)
check = pd.merge(allunique,PortMappingsPorts, indicator=True)
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

print(ClipperRawData.dtypes)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())

PortMappingsPorts['Ports'] = pd.DataFrame(PortMappings['Clipper Port Name'])
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())

allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={'0':'Ports'})

PortMappingsPorts = pd.DataFrame(PortMappings['Clipper Port Name'])
PortMappingsPorts = PortMappingsPorts.rename(columns={'Clipper Port Name':'Ports'})

check = pd.merge(allunique,PortMappingsPorts, indicator=True)
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={'0':'Ports'})
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
check = pd.merge(allunique,PortMappingsPorts, indicator=True)
check = pd.merge(allunique,PortMappingsPorts, how='outer', indicator=True)
allunique_lower = allunique.str.lower()
allunique_lower = allunique['Ports'].str.lower()
PortMappingsPorts_lower = PortMappingsPorts['Ports'].str.lower()
allunique_lower = allunique['Ports'].str.lower()
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)
PortsNotMapped = check[check['_merge' == 'left_only']]
PortsNotMapped = check[check['_merge'] == 'left_only']
countries = pd.Series(ClipperRawData['offtake_country'].unique())
countries_check = pd.merge(PortsNotMapped, ClipperDataRaw.apply(lambda x: x.astype(str).str.lower()), how='left')
countries_check = pd.merge(PortsNotMapped, ClipperRawData.apply(lambda x: x.astype(str).str.lower()), how='left')
countries_check = pd.merge(PortsNotMapped[0], ClipperRawData[13].apply(lambda x: x.astype(str).str.lower()), how='left')
PortsNotMapped[0]
ClipperRawDataLoadPorts = ClipperRawData.rename(columns={'load_port':'Ports'})
countries_check = pd.merge(PortsNotMapped, ClipperRawDataLoadPorts.apply(lambda x: x.astype(str).str.lower()), how='left')
clean_countries_check = pd.DataFrame(countries_check[['Ports','Load Country', 'Load Region']].unique())
clean_countries_check = pd.DataFrame(countries_check[['Ports','load_country', 'load_region']].unique())
clean_countries_check = pd.DataFrame(countries_check[['Ports','load_country', 'load_region']].unique)
clean_countries_check = countries_check[['Ports','load_country', 'load_region']].
clean_countries_check = countries_check[['Ports','load_country', 'load_region']]
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
MappingData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Mapping")
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.Series(MedFlowsData['Load Port'].unique())
LoadPorts = pd.Series(MedFlowsData['Load Port'].str.lower().unique())
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.Series(MedFlowsData['Load Port'].str.lower().unique())
MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())


### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts_lower = pd.DataFrame(TargoPorts['Ports'].str.lower())
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())


### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts_lower = pd.DataFrame(TargoPorts['Ports'].str.lower())

F3check = pd.merge(TargoPorts,LoadPorts, how='outer', indicator=True)
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())
LoadPorts= LoadPorts.rename(columns={0:'Ports'})

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts_lower = pd.DataFrame(TargoPorts['Ports'].str.lower())

F3check = pd.merge(TargoPorts,LoadPorts, how='outer', indicator=True)
F3check = pd.merge(LoadPorts,TargoPorts, how='outer', indicator=True)
MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())
LoadPorts= LoadPorts.rename(columns={0:'Ports'})

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts_lower = pd.DataFrame(TargoPorts['Ports'].str.lower())

F3check = pd.merge(LoadPorts,TargoPorts, how='outer', indicator=True)
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F3.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())
LoadPorts= LoadPorts.rename(columns={0:'Ports'})

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts = pd.DataFrame(TargoPorts['Ports'].str.lower())

F3check = pd.merge(LoadPorts,TargoPorts, how='outer', indicator=True)
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F31.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())
LoadPorts= LoadPorts.rename(columns={0:'Ports'})

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts = pd.DataFrame(TargoPorts['Ports'].str.lower())

F3check = pd.merge(LoadPorts,TargoPorts, how='outer', indicator=True)
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

print(ClipperRawData.dtypes)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need as a pandas data series
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
PortMappingsPorts = pd.DataFrame(PortMappings['Clipper Port Name'])
PortMappingsPorts = PortMappingsPorts.rename(columns={'Clipper Port Name':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F31.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())
LoadPorts= LoadPorts.rename(columns={0:'Ports'})

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts = pd.DataFrame(TargoPorts['Ports'].str.lower())

F3check = pd.merge(LoadPorts,TargoPorts, how='outer', indicator=True)
import pandas as pd
import numpy as np

MedFlowsData = pd.read_excel('L:\TRADING\ANALYSIS\GLOBAL\MED Balances\Flows Med Sweet  F31.xlsm', sheetname="Apex edited Data")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
StaticData = pd.read_excel('L:\TRADING\Targo\Mapping.xlsx', sheetname="Static Data")
PortCoords = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")


### This is another way to sort for unique names in the list
#UniqueMappingDataLordPorts = list(set(MedFlowsData['Load Port']))

LoadPorts = pd.DataFrame(MedFlowsData['Load Port'].str.lower().unique())
LoadPorts= LoadPorts.rename(columns={0:'Ports'})

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
TargoPorts = pd.DataFrame(PortMappings['Targo Port Name'])
TargoPorts = TargoPorts.rename(columns={'Targo Port Name':'Ports'})
TargoPorts = pd.DataFrame(TargoPorts['Ports'].str.lower())

F3check = pd.merge(LoadPorts,TargoPorts, how='outer', indicator=True)
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

print(ClipperRawData.dtypes)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need as a pandas data series
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())


### add the load ports to the discharge ports and return as a DataFrame, rename column to Ports for comparing and also and lower case for comparison
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
PortMappingsPorts = pd.DataFrame(PortMappings['Clipper Port Name'])
PortMappingsPorts = PortMappingsPorts.rename(columns={'Clipper Port Name':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())

### merge both to see which is in which list
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)

PortsNotMapped = check[check['_merge'] == 'left_only']
ClipperPortsNotMapped = check[check['_merge'] == 'left_only']
TargoPortsNotMapped = check[check['_merge'] == 'right_only']
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

print(ClipperRawData.dtypes)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need as a pandas data series
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())


### add the load ports to the discharge ports and return as a DataFrame, rename column to Ports for comparing and also and lower case for comparison
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
PortMappingsPorts = pd.DataFrame(PortMappings['Clipper Port Name'])
PortMappingsPorts = PortMappingsPorts.rename(columns={'Clipper Port Name':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())

### merge both to see which is in which list
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)

ClipperPortsNotMapped = check[check['_merge'] == 'left_only']
TargoPortsNotMapped = check[check['_merge'] == 'right_only']
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")
x = PortCoordsTEST.loc[PortCoordsTEST['Latitude'] > 30]
x = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] > 30) & (PortCoordsTEST['Longtitude'] > 30) ]
x = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] > 30) & (PortCoordsTEST['Longitude'] > 30) ]
portlist = []
portlist.append('Ceyan')
PortCoordsTEST['Latitude']
PortCoordsTEST['TargoAssetName'] in portlist
portlist = []
portlist.append('Ceyhan')
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] in portlist]
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin portlist]
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)]
x['Latitude']+0.015
(x['Latitude']+0.015) < PortCoordsTEST['Latitude'] < (x['Latitude']-0.015)
x['Latitude']
PortCoordsTEST['Latitude']
x['Latitude']+0.015
x['Latitude']
y = PortCoordsTEST.loc[(x['Latitude']+0.015) < PortCoordsTEST['Latitude'] < (x['Latitude']-0.015)]
y = PortCoordsTEST.iloc[(x['Latitude']+0.015) < PortCoordsTEST['Latitude'] < (x['Latitude']-0.015)]
y = PortCoordsTEST.loc[(x['Latitude']+0.015) < x < (x['Latitude']-0.015)]
x
y = PortCoordsTEST.loc[(x['Latitude']+0.015) < PortCoordsTEST.loc(x) < (x['Latitude']-0.015)]
y = PortCoordsTEST.loc[(x['Latitude']+0.015) < PortCoordsTEST.loc(x['Latitude']) < (x['Latitude']-0.015)]
PortCoordsTEST.loc(x['Latitude'])
y = PortCoordsTEST.loc[(x['Latitude']+0.015)]
(x['Latitude']+0.015)
y = PortCoordsTEST.loc[PortCoordsTEST['Latitude'] > (x['Latitude']+0.015)]
portlist = []
portlist.append('Ceyhan')
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)]
x = x.sort_index(inplace=True)


y = PortCoordsTEST.loc[PortCoordsTEST['Latitude'] > (x['Latitude']+0.015)]
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)]
portlist = []
portlist.append('Ceyhan')
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)]
x = list(x['Latitude'])


y = PortCoordsTEST.loc[PortCoordsTEST['Latitude'] > (x+0.015)]
y = PortCoordsTEST.loc[PortCoordsTEST['Latitude'] > ([x+0.015])]
rows = PortCoordsTEST.loc[PortCoordsTEST['Latitude'] > 5]
rows = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist) | 
        PortCoordsTEST['TargoAssetName'].isbetween(30,40, inclusive=True)]
rows = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist) | 
        PortCoordsTEST['TargoAssetName'].between(30,40, inclusive=True)]
rows = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist) | 
        PortCoordsTEST['Latitude'].between(30,40, inclusive=True)]
PortCoordsTEST['TargoAssetName'].isin(portlist)
PortCoordsTEST['TargoAssetName'].isin(portlist).between(30,40, inclusive=True)
PortCoordsTEST['TargoAssetName'].isin(portlist)[PortCoordsTEST['Latitude'].between(30,40, inclusive=True)]
p = PortCoordsTEST['TargoAssetName'].isin(portlist)[PortCoordsTEST['Latitude'].between(30,40, inclusive=True)]
p = PortCoordsTEST['TargoAssetName'].isin(portlist)
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)]
ab = PortCoordsTEST.loc[PortCoordsTEST['Latitude'].between(x['Latitude']+1,x['Latitude']+5, inclusive=True)]
x['Latitude']+1
PortCoordsTEST['Latitude']
mask = x['Latitude']


ab = PortCoordsTEST.loc[PortCoordsTEST['Latitude'].between(mask+1,mask+5, inclusive=True)]
mask = PortCoordsTEST.mask((PortCoordsTEST['Latitude'] > x['Latitude']+5) & (PortCoordsTEST['Latitude'] < x['Latitude']+5))
mask = PortCoordsTEST.mask((PortCoordsTEST['Latitude'] > x.loc[0,'Latitude']+5) & (PortCoordsTEST['Latitude'] < x.loc[0,'Latitude']+5))
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)].reset_index()
mask = PortCoordsTEST.mask((PortCoordsTEST['Latitude'] > x.loc[0,'Latitude']+5) & (PortCoordsTEST['Latitude'] < x.loc[0,'Latitude']+5))
ab = PortCoordsTEST.loc[PortCoordsTEST['Latitude'].between(mask+1,mask+5, inclusive=True)]
portlist = []
portlist.append('Ceyhan','Ceyhan Botas')
portlist = []
portlist.append(['Ceyhan','Ceyhan Botas'])
portlist = []
portlist.append['Ceyhan','Ceyhan Botas']
portlist = []
portlist.append(['Ceyhan','Ceyhan Botas'])
portlist = []
portlist.append('Ceyhan','Ceyhan Botas')
portlist = []
portlist.append(list('Ceyhan','Ceyhan Botas'))
portlist = []
portlist.append('Ceyhan')
portlist = []
portlist.append(['Ceyhan Botas','Ceyhan'])
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)].reset_index()
portlist = []
portlist.append(set['Ceyhan Botas','Ceyhan'])
portlist = []
portlist = portlist.append(['Ceyhan Botas','Ceyhan'])
portlist = []
portlist = ['Ceyhan Botas','Ceyhan']
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)].reset_index()
y = PortCoordsTEST.where(PortCoordsTEST['Latitude'] > x['Latitude'])
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)].reset_index()

PortCoordsTEST.rest_index()
x = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)].reset_index()

PortCoordsTEST.reset_index()
y = PortCoordsTEST.where(PortCoordsTEST['Latitude'] > x['Latitude'])
y = PortCoordsTEST.where(PortCoordsTEST['Latitude'] > ( PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'].isin(portlist)])['Latitude'])
y = PortCoordsTEST.where(PortCoordsTEST['Latitude'] > 5)
y = PortCoordsTEST.loc(PortCoordsTEST['Latitude'] > 5)
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")
y = PortCoordsTEST.loc(PortCoordsTEST['Latitude'] > 5)
print(y)
y = PortCoordsTEST.loc[PortCoordsTEST['Latitude'] > 5]
y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < 30) & (PortCoordsTEST['Latitude'] > 31) ]
y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < 31) & (PortCoordsTEST['Latitude'] > 30) ]
y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < 31) &
                       (PortCoordsTEST['Latitude'] > 30) &
                       (PortCoordsTEST['Longitude'] > 30) &
                       (PortCoordsTEST['Longitude'] > 31)]
y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < 31) &
                       (PortCoordsTEST['Latitude'] > 30) &
                       (PortCoordsTEST['Longitude'] > 30) &
                       (PortCoordsTEST['Longitude'] < 31)]
y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < 31) &
                       (PortCoordsTEST['Latitude'] > 30) &
                       (PortCoordsTEST['Longitude'] > 20) &
                       (PortCoordsTEST['Longitude'] < 31)]
choice_lat = 30
choice_lon = 30
boundry = 5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] > min_lon) &
                       (PortCoordsTEST['Longitude'] < max_lon)]
choice_lat = 30
choice_lon = 30
boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] > min_lon) &
                       (PortCoordsTEST['Longitude'] < max_lon)]
choice_lat = 30
choice_lon = 40
boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] > min_lon) &
                       (PortCoordsTEST['Longitude'] < max_lon)]
choice_lat = 36
choice_lon = 35
boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] > min_lon) &
                       (PortCoordsTEST['Longitude'] < max_lon)]
choice_lon = 36.5
choice_lat = 35.9
boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] > min_lon) &
                       (PortCoordsTEST['Longitude'] < max_lon)]
choice_lat = 40
choice_lon = 30

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
choice_lat = 40
choice_lon = 30

boundry = 10

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
choice_lat = 36
choice_lon = 35

boundry = 10

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
choice_lat = 36
choice_lon = 35

boundry = 1

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
choice_lat = 36.5
choice_lon = 35.5

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
port = ceyhan

choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == str(port)]['Latitude'].values
port = 'ceyhan'

choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == port]['Latitude'].values
choice_lon = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == port]['Longitude'].values
boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
port = 'ceyhan'

choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == port]['Latitude'].values
choice_lon = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == port]['Longitude'].values

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

port = 'ceyhan'

choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == port]['Latitude'].values
choice_lon = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == port]['Longitude'].values

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == port]['Latitude'].values
PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

portname = 'ceyhan'

choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values
PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

portname = 'Ceyhan'

choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values
choice_lon = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

portname = 'Ceyhan'

choice_lat = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values
choice_lon = PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
(PortCoordsTEST['Latitude'] < max_lat)
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

portname = 'Ceyhan'

choice_lat = int(PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values)
choice_lon = int(PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values)

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

portname = 'Ceyhan'

choice_lat = (PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values).astype(float64)
choice_lon = (PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values).astype(float64)

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

portname = 'Ceyhan'

choice_lat = (PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values).astype(float)
choice_lon = (PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values).astype(float)

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")

portname = 'Ceyhan'

choice_lat = float(PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values)
choice_lon = float (PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values)

boundry = 0.5

max_lat = choice_lat + boundry
min_lat = choice_lat - boundry
max_lon = choice_lon + boundry
min_lon = choice_lon - boundry

y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                       (PortCoordsTEST['Latitude'] > min_lat) &
                       (PortCoordsTEST['Longitude'] < max_lon) &
                       (PortCoordsTEST['Longitude'] > min_lon)]
def find_similar_ports(portname, limit):
    PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")
    choice_lat = float(PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values)
    choice_lon = float (PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values) 
    max_lat = choice_lat + limit
    min_lat = choice_lat - limit
    max_lon = choice_lon + limit
    min_lon = choice_lon - limit
    y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                           (PortCoordsTEST['Latitude'] > min_lat) &
                           (PortCoordsTEST['Longitude'] < max_lon) &
                           (PortCoordsTEST['Longitude'] > min_lon)]
    return y

find_similar_ports('Ceyhan',0.5)
mport pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

print(ClipperRawData.dtypes)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need as a pandas data series
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())


### add the load ports to the discharge ports and return as a DataFrame, rename column to Ports for comparing and also and lower case for comparison
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
PortMappingsPorts = pd.DataFrame(PortMappings['Clipper Port Name'])
PortMappingsPorts = PortMappingsPorts.rename(columns={'Clipper Port Name':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())

### merge both to see which is in which list
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)

ClipperPortsNotMapped = check[check['_merge'] == 'left_only']
TargoPortsNotMapped = check[check['_merge'] == 'right_only']
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)

print(ClipperRawData.dtypes)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values

### get the unique port names that we need as a pandas data series
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())


### add the load ports to the discharge ports and return as a DataFrame, rename column to Ports for comparing and also and lower case for comparison
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
PortMappingsPorts = pd.DataFrame(PortMappings['Clipper Port Name'])
PortMappingsPorts = PortMappingsPorts.rename(columns={'Clipper Port Name':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())

### merge both to see which is in which list
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)

ClipperPortsNotMapped = check[check['_merge'] == 'left_only']
TargoPortsNotMapped = check[check['_merge'] == 'right_only']


### Unique offtake countries
countries = pd.Series(ClipperRawData['offtake_country'].unique())
find_similar_ports('Ceyhan',0.5)
def find_similar_ports(portname, limit):
    PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")
    choice_lat = float(PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Latitude'].values)
    choice_lon = float (PortCoordsTEST.loc[PortCoordsTEST['TargoAssetName'] == portname]['Longitude'].values) 
    max_lat = choice_lat + limit
    min_lat = choice_lat - limit
    max_lon = choice_lon + limit
    min_lon = choice_lon - limit
    y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < max_lat) &
                           (PortCoordsTEST['Latitude'] > min_lat) &
                           (PortCoordsTEST['Longitude'] < max_lon) &
                           (PortCoordsTEST['Longitude'] > min_lon)]
    return y

find_similar_ports('Ceyhan',0.5)
tableports = find_similar_ports('Ceyhan',0.5)
tableports = find_similar_ports('Ceyhan',0.5)[:,3]
tableports = find_similar_ports('Ceyhan',0.5)[3]

## ---(Wed Dec 27 12:14:48 2017)---
import pandas as pd

PortCoordsTEST = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortCoords.xlsx', sheetname="PortCoords")
load_verification = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE', header='Load Port VErification')
import pandas as pd

load_verification = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE', header='Load Port VErification')
import pandas as pd

load_verification = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE', header='Load Port Verification')
load_verification = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE')
import pandas as pd

targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE')
targo_references['Load Port VErification']
targo_references['Load Port Verification']
import pandas as pd

targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE')

load_discharge = targo_references['Load Port Verification']
counterparty = targo_references['Equity']
grade = targo_references['Equity']
load_discharge = targo_references['Load Port Verification'].dropna
load_discharge = pd.Series[targo_references['Load Port Verification'].dropna]
load_discharge = pd.Series(targo_references['Load Port Verification'].dropna)
load_discharge = targo_references['Load Port Verification'].dropna()
import pandas as pd

targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE')

load_discharge = targo_references['Load Port Verification'].dropna()
counterparty = targo_references['Equity'].dropna()
grade = targo_references['Equity'].dropna()
import pandas as pd

targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE')

load_discharge = targo_references['Load Port Verification'].dropna()
counterparty = targo_references['Equity'].dropna()
grade = targo_references['Grade'].dropna()
import pandas as pd

targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
                                  sheetname='REFERENCE')

load_discharge = targo_references['Load Port Verification'].dropna()
counterparty = targo_references['Equity'].dropna()
grade = targo_references['Grades'].dropna()
targo_mappings = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\Targo Ports - Products V1.0.xlsx')
targo_mappings = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\Targo Ports - Products V1.0.xlsx', sheetname='Targo Products')
PortMappings = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\PortMappings.xlsx", sheet = 0)
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Raw data.csv")
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName'])
PortMappingsPorts = PortMappingsPorts.rename(columns={'ClipperPortName':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName']).dropna()
PortMappingsPorts = PortMappingsPorts.rename(columns={'ClipperPortName':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName']).unique().dropna()
PortMappingsPorts = PortMappingsPorts.rename(columns={'ClipperPortName':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName']).dropna()
PortMappingsPorts = PortMappingsPorts.unique()
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName'].unique()).dropna()
PortMappingsPorts = PortMappingsPorts.rename(columns={'ClipperPortName':'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())
print(PortMappings_headers)
PortMappings['ClipperPortName'].unique()
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName'].unique()).dropna()
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName'].unique()).dropna()
PortMappingsPorts = PortMappingsPorts.rename(columns={0:'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)
ClipperPortsNotMapped = check[check['_merge'] == 'left_only']
TargoPortsNotMapped = check[check['_merge'] == 'right_only']
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())
name_convention_check = pd.merge(ClipperPortsNotMapped,TargoPortNameColumn_lower, how='outer', indicator=True)
name_convention_check = name_convention_check[name_convention_check['_merge'] == 'left_only']
abc = name_convention_check[name_convention_check['_merge'] == 'left_only']
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())
name_convention_check = pd.merge(ClipperPortsNotMapped,TargoPortNameColumn_lower, how='outer', indicator=True)
abc = name_convention_check[name_convention_check['_merge'] == 'left_only']
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())
name_convention_check = pd.merge(ClipperPortsNotMapped,TargoPortNameColumn_lower, how='outer', on = 'Ports',indicator=True)
abc = name_convention_check[name_convention_check['_merge'] == 'left_only']
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())
TargoTempCheck = ClipperPortsNotMapped.drop(columns='_merge')
TargoTempCheck = ClipperPortsNotMapped.drop('_merge')
ClipperPortsNotMapped
TargoTempCheck = ClipperPortsNotMapped['Ports']
TargoTempCheck = ClipperPortsNotMapped['Ports']
name_convention_check = pd.merge(TargoTempCheck,TargoPortNameColumn_lower, how='outer',indicator=True)
abc = name_convention_check[name_convention_check['_merge'] == 'left_only']
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())

TargoTempCheck = pd.DataFrame(ClipperPortsNotMapped['Ports'])
name_convention_check = pd.merge(TargoTempCheck,TargoPortNameColumn_lower, how='outer',indicator=True)
abc = name_convention_check[name_convention_check['_merge'] == 'left_only']
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheetname='Data')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
import pandas as pd

ClipperRawData = pd.read_csv("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheet='Data')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
import pandas as pd

ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheet='Data')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values


### get the unique port names that we need as a pandas data series
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName'].unique()).dropna()
PortMappingsPorts = PortMappingsPorts.rename(columns={0:'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())

### merge both to see which is in which list
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)
ClipperPortsNotMapped = check[check['_merge'] == 'left_only']
TargoPortsNotMapped = check[check['_merge'] == 'right_only']

### This is the targo port name column
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())


### Then check to see if the ports we think are missing from above are in TargoPortName, returns completely missing ports
TargoTempCheck = pd.DataFrame(ClipperPortsNotMapped['Ports'])
name_convention_check = pd.merge(TargoTempCheck,TargoPortNameColumn_lower, how='outer',indicator=True)
NotAnywhere = name_convention_check[name_convention_check['_merge'] == 'left_only']
targo_mappings = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\Targo Ports - Products V1.0.xlsx', sheetname='Targo Products')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
gasoline_tracking = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ProductsClipperInput\GASTRACKER.xlsx", sheet='Tracker')
import pandas as pd
targo_mappings = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\Targo Ports - Products V1.0.xlsx', sheetname='Targo Products')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
gas_tracking = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ProductsClipperInput\GASTRACKER.xlsx", sheet='Tracker')
targo_mappings = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\Targo Ports - Products V1.0.xlsx', sheetname='Targo Products')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
gas_tracking = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ProductsClipperInput\GASTRACKER.xlsx", sheetname='Tracker')
import pandas as pd

# =============================================================================
# targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
#                                   sheetname='REFERENCE')
# =============================================================================



targo_mappings = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\ClipperTargoStuff\Targo Ports - Products V1.0.xlsx', sheetname='Targo Products')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')
gas_tracking = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\ProductsClipperInput\GASTRACKER.xlsx", sheetname='Tracker')
targo_references = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx", sheetname='REFERENCE')

load_discharge = targo_references['Load Port Verification'].dropna()
counterparty = targo_references['Equity'].dropna()
grade = targo_references['Grades'].dropna()
port_ref = targo_references['Load Port Verification'].dropna()
counterparty_ref = targo_references['Equity'].dropna()
grade_ref = targo_references['Grades'].dropna()
port_ref = pd.DataFrame(targo_references['Load Port Verification'].dropna()).unique()
port_ref = pd.DataFrame(targo_references['Load Port Verification'].unique()).dropna()
port_ref = pd.DataFrame(targo_references['Load Port Verification'].unique()).dropna()
port_ref = port_ref.rename(columns={0:'Ports'})
port_ref = pd.DataFrame(port_ref['Ports'].str.lower())

counterparty_ref = pd.DataFrame(targo_references['Equity'].unique()).dropna()
counterparty_ref = counterparty_ref.rename(columns={0:'Equity'})
counterparty_ref = pd.DataFrame(counterparty_ref['Equity'].str.lower())

grade_ref = pd.DataFrame(targo_references['Grades'].unique()).dropna()
grade_ref = grade_ref.rename(columns={0:'Grades'})
grade_ref = pd.DataFrame(grade_ref['Grades'].str.lower())
chrts = pd.DataFrame(gas_tracking['CHRTS'].unique()).dropna()
chrts = chrts.rename(columns={0:'Equity'})
chrts = pd.DataFrame(chrts['Equity'].str.lower())
chrts = pd.DataFrame(gas_tracking['CHRTS'].unique()).dropna()
chrts = pd.DataFrame(gas_tracking['CHRTS']).dropna()
chrts = pd.DataFrame((gas_tracking['CHRTS']).dropna().unique())
gas_tracking['CHRTS']
(gas_tracking['CHRTS']).dropna()
chrts = pd.DataFrame((gas_tracking['CHRTS'].astype(str)).dropna().unique())
chrts = pd.DataFrame((gas_tracking['CHRTS'].astype(str)).dropna().unique())
chrts = chrts.rename(columns={0:'Equity'})
chrts = pd.DataFrame(chrts['Equity'].str.lower())
gas_tracking['CHRTS'].rstrip()).dropna().unique()
chrts = pd.DataFrame((gas_tracking['CHRTS'].rstrip().dropna().unique())
gas_tracking['CHRTS'].rstrip()
gas_tracking['CHRTS'].str.rstrip()
gas_tracking['CHRTS'].str.rstrip().dropna().unique()
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna().unique())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna().unique())
chrts = chrts.rename(columns={0:'Equity'})
chrts = pd.DataFrame(chrts['Equity'].str.lower())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna())
chrts = chrts.rename(columns={0:'Equity'})
chrts = pd.DataFrame(chrts['Equity'].str.lower().unique())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().unique().dropna())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna().unique())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna().unique())
chrts = chrts.rename(columns={0:'Equity'})
chrts = pd.DataFrame(chrts['Equity'].str.lower().unique())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna().unique())
chrts = pd.DataFrame(chrts[0].str.lower().unique())
chrts = chrts.rename(columns={0:'Equity'})
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna().unique())
chrts = pd.DataFrame(chrts[0].str.lower().unique())
chrts = chrts.rename(columns={0:'Equity'})

chrt_check = pd.merge(counterparty_ref,chrts, how='outer', indicator=True)
#ClipperPortsNotMapped = chrt_check[chrt_check['_merge'] == 'left_only']
NotInCHRTCheck = chrt_check[chrt_check['_merge'] == 'right_only']
targo_references = pd.read_excel("L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx", sheetname='REFERENCE')
port_ref = pd.DataFrame(targo_references['Load Port Verification'].unique()).dropna()
port_ref = port_ref.rename(columns={0:'Ports'})
port_ref = pd.DataFrame(port_ref['Ports'].str.lower())

counterparty_ref = pd.DataFrame(targo_references['Equity'].unique()).dropna()
counterparty_ref = counterparty_ref.rename(columns={0:'Equity'})
counterparty_ref = pd.DataFrame(counterparty_ref['Equity'].str.lower())

grade_ref = pd.DataFrame(targo_references['Grades'].unique()).dropna()
grade_ref = grade_ref.rename(columns={0:'Grades'})
grade_ref = pd.DataFrame(grade_ref['Grades'].str.lower())
chrts = pd.DataFrame(gas_tracking['CHRTS'].str.rstrip().dropna().unique())
chrts = pd.DataFrame(chrts[0].str.lower().unique())
chrts = chrts.rename(columns={0:'Equity'})

chrt_check = pd.merge(counterparty_ref,chrts, how='outer', indicator=True)
#ClipperPortsNotMapped = chrt_check[chrt_check['_merge'] == 'left_only']
NotInCHRTCheck = chrt_check[chrt_check['_merge'] == 'right_only']
LoadPorts = pd.Series(gas_tracking['LOAD'].str.rstrip().str.lower().dropna().unique())
LoadPorts = pd.Series(gas_tracking['LOAD'].str.rstrip().str.lower().dropna().unique())
DischargePorts = pd.Series(gas_tracking['DISCHARGE'].str.rstrip().str.lower().dropna().unique())
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
LoadPorts = pd.Series(gas_tracking['LOAD'].str.rstrip().str.lower().dropna().unique())
DischargePorts = pd.Series(gas_tracking['DISCH'].str.rstrip().str.lower().dropna().unique())
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
LoadPorts = pd.Series(gas_tracking['LOAD'].str.rstrip().str.lower().dropna().unique())
DischargePorts = pd.Series(gas_tracking['DISCH'].str.rstrip().str.lower().dropna().unique())
ports=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
ports= ports.rename(columns={0:'Ports'})

port_check = pd.merge(port_ref,ports, how='outer', indicator=True)
port_check = pd.merge(port_ref,ports, how='outer', indicator=True)
NotInPORTCheck = port_check[port_check['_merge'] == 'right_only']
LoadPorts = pd.Series(gas_tracking['LOAD'].str.rstrip().str.lower().dropna().unique())
DischargePorts = pd.Series(gas_tracking['DISCH'].str.rstrip().str.lower().dropna().unique())
ports=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
ports= ports.rename(columns={0:'Ports'})
port_ref = pd.DataFrame(targo_references['Load Port Verification'].unique()).dropna()
port_ref = port_ref.rename(columns={0:'Ports'})
port_ref = pd.DataFrame(port_ref['Ports'].str.lower())
LoadPorts = pd.Series(gas_tracking['LOAD'].str.rstrip().str.lower().dropna().unique())
DischargePorts = pd.Series(gas_tracking['DISCH'].str.rstrip().str.lower().dropna().unique())
ports=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
ports= ports.rename(columns={0:'Ports'})

port_check = pd.merge(port_ref,ports, how='outer', indicator=True)
NotInPORTCheck = port_check[port_check['_merge'] == 'right_only']
targo_mappings_port_list = pd.DataFrame(targo_mappings['Port'].str.rstrip().dropna().unique())
targo_mappings_port_list = pd.DataFrame(targo_mappings['Port'].str.rstrip().dropna().unique()).rename(columns={0:'Ports'})
targo_mappings_port_list = pd.DataFrame(targo_mappings['Port'].str.rstrip().dropna().unique()).rename(columns={0:'Ports'})
product_port_check = pd.merge(port_ref,targo_mappings_port_list, how='outer', indicator=True)
NotInPORTCheckVSTargoPortList = product_port_check[product_port_check['_merge'] == 'right_only']
targo_mappings_port_list = pd.DataFrame(targo_mappings['Port'].str.rstrip().str.lower().dropna().unique()).rename(columns={0:'Ports'})
product_port_check = pd.merge(port_ref,targo_mappings_port_list, how='outer', indicator=True)
NotInPORTCheckVSTargoPortList = product_port_check[product_port_check['_merge'] == 'right_only']
import pandas as pd

ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheet='Data')
PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapping')

print(ClipperRawData.dtypes)

### give me the unique column headers
ClipperRawData_headers = ClipperRawData.columns.values
PortMappings_headers = PortMappings.columns.values


### get the unique port names that we need as a pandas data series
LoadPorts = pd.Series(ClipperRawData['load_port'].unique())
DischargePorts = pd.Series(ClipperRawData['offtake_port'].unique())
allunique=pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
allunique= allunique.rename(columns={0:'Ports'})
allunique_lower = pd.DataFrame(allunique['Ports'].str.lower())

### turn the original port mappinngs into a dataframe for comparison, rename for merging and make sure and lower case for check
PortMappingsPorts = pd.DataFrame(PortMappings['ClipperPortName'].unique()).dropna()
PortMappingsPorts = PortMappingsPorts.rename(columns={0:'Ports'})
PortMappingsPorts_lower = pd.DataFrame(PortMappingsPorts['Ports'].str.lower())

### merge both to see which is in which list
check = pd.merge(allunique_lower,PortMappingsPorts_lower, how='outer', indicator=True)
ClipperPortsNotMapped = check[check['_merge'] == 'left_only']
TargoPortsNotMapped = check[check['_merge'] == 'right_only']

### This is the targo port name column
TargoPortNameColumn = pd.DataFrame(PortMappings['TargoPortName'].unique()).dropna()
TargoPortNameColumn = TargoPortNameColumn.rename(columns={0:'Ports'})
TargoPortNameColumn_lower = pd.DataFrame(TargoPortNameColumn['Ports'].str.lower())


### Then check to see if the ports we think are missing from above are in TargoPortName, returns completely missing ports
TargoTempCheck = pd.DataFrame(ClipperPortsNotMapped['Ports'])
name_convention_check = pd.merge(TargoTempCheck,TargoPortNameColumn_lower, how='outer',indicator=True)
NotAnywhere = name_convention_check[name_convention_check['_merge'] == 'left_only']
import pandas as pd

# =============================================================================
# targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
#                                   sheetname='REFERENCE')
# =============================================================================

PortMappings = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Mapped Ports')
AllTargoPorts = pd.read_excel("L:\TRADING\Targo\Mapping.xlsx", sheet = 'Targo Ports')
import pandas as pd

# =============================================================================
# targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
#                                   sheetname='REFERENCE')
# =============================================================================

PortMappings = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheet = 'Mapped Ports')
AllTargoPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheet = 'Targo Ports')
import pandas as pd

# =============================================================================
# targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
#                                   sheetname='REFERENCE')
# =============================================================================

PortMappings = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheet = 'Mapped Ports')
AllTargoPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheet = 'TARGO Ports')
import pandas as pd

# =============================================================================
# targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
#                                   sheetname='REFERENCE')
# =============================================================================

PortMappings = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'Mapped Ports')
AllTargoPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'TARGO Ports')
ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheetname='Data')
LoadPorts = pd.DataFrame(ClipperRawData['load_port'].str.lower().dropna().unique())
LoadPorts = pd.DataFrame(ClipperRawData['load_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
LoadPorts = pd.DataFrame(ClipperRawData['load_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
DischargePorts = pd.DataFrame(ClipperRawData['offtake_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
AllClipperPorts = pd.DataFrame((LoadPorts.append(DischargePorts)).unique())
AllClipperPorts = pd.DataFrame(LoadPorts.append(DischargePorts))
AllClipperPorts = pd.DataFrame(LoadPorts.append(DischargePorts)).drop_duplicates()
CurrentClipperVsMappedPorts = pd.merge(PortMappings['Location'].str.lower().rename(columns={0:'Ports'})
                                            ,AllClipperPorts, how='outer', indicator=True)
CurrentClipperVsMappedPorts = pd.merge(pd.DataFrame(PortMappings['Location'].str.lower().rename(columns={0:'Ports'}))
                                            ,AllClipperPorts, how='outer', indicator=True)
CurrentClipperVsMappedPorts = pd.merge(pd.DataFrame(PortMappings['Location'].str.lower()).rename(columns={0:'Ports'})
                                            ,AllClipperPorts, how='outer', indicator=True)
pd.DataFrame(PortMappings['Location'].str.lower()).rename(columns={0:'Ports'})
CurrentClipperVsMappedPorts = pd.merge((pd.DataFrame(PortMappings['Location'].str.lower()).rename(columns={0:'Ports'}))
                                            ,AllClipperPorts, how='outer', indicator=True)
MappedPorts = pd.DataFrame(PortMappings['Location'].str.lower()).rename(columns={0:'Ports'})
LoadPorts = pd.DataFrame(ClipperRawData['load_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
DischargePorts = pd.DataFrame(ClipperRawData['offtake_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
AllClipperPorts = pd.DataFrame(LoadPorts.append(DischargePorts)).drop_duplicates()
MappedPorts = pd.DataFrame(PortMappings['Location'].str.lower()).rename(columns={'Location':'Ports'})

CurrentClipperVsMappedPorts = pd.merge(MappedPorts,AllClipperPorts, how='outer', indicator=True)
LoadPorts = pd.DataFrame(ClipperRawData['load_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
DischargePorts = pd.DataFrame(ClipperRawData['offtake_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
AllClipperPorts = pd.DataFrame(LoadPorts.append(DischargePorts)).drop_duplicates()
MappedPorts = pd.DataFrame(PortMappings['Location'].str.lower()).rename(columns={'Location':'Ports'})

CurrentClipperVsMappedPorts = pd.merge(MappedPorts,AllClipperPorts, how='outer', indicator=True)

InMapped = CurrentClipperVsMappedPorts[CurrentClipperVsMappedPorts['_merge'] == 'left_only']
AllClipperPorts = CurrentClipperVsMappedPorts[CurrentClipperVsMappedPorts['_merge'] == 'right_only']
LoadPorts = pd.DataFrame(ClipperRawData['load_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
DischargePorts = pd.DataFrame(ClipperRawData['offtake_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
AllClipperPorts = pd.DataFrame(LoadPorts.append(DischargePorts)).drop_duplicates()
MappedPorts = pd.DataFrame(PortMappings['Location'].str.lower()).rename(columns={'Location':'Ports'})

CurrentClipperVsMappedPorts = pd.merge(MappedPorts,AllClipperPorts, how='outer', indicator=True)

InMapped = CurrentClipperVsMappedPorts[CurrentClipperVsMappedPorts['_merge'] == 'left_only']
InClipper = CurrentClipperVsMappedPorts[CurrentClipperVsMappedPorts['_merge'] == 'right_only']
TargoPorts = pd.DataFrame(AllTargoPorts['Name'].str.lower()).rename(columns={'Name':'Ports'})
CurrentClipperVsAllTargoPorts = pd.merge(TargoPorts,AllClipperPorts, how='outer', indicator=True)
InTargo = CurrentClipperVsAllTargoPorts[CurrentClipperVsAllTargoPorts['_merge'] == 'left_only']
InClipperVsTargo = CurrentClipperVsAllTargoPorts[CurrentClipperVsAllTargoPorts['_merge'] == 'right_only']
CheckVsTargoList = pd.merge(pd.DataFrame(AllTargoPorts['Name'].str.lower()).rename(columns={'Name':'Ports'}),
                            pd.DataFrame(InClipper['Ports']), how='outer', indicator=True)
CheckVsTargoList = pd.merge(pd.DataFrame(AllTargoPorts['Name'].str.lower()).rename(columns={'Name':'Ports'}),
                            pd.DataFrame(InClipper['Ports']), how='outer', indicator=True)
CheckVsTargoList = CheckVsTargoList[CheckVsTargoList['_merge'] == 'left_only']
CheckVsTargoList = pd.merge(pd.DataFrame(AllTargoPorts['Name'].str.lower()).rename(columns={'Name':'Ports'}),
                            pd.DataFrame(InClipper['Ports']), how='outer', indicator=True)
CheckVsTargoList = CheckVsTargoList[CheckVsTargoList['_merge'] == 'right_only']

## ---(Tue Jan  2 11:47:44 2018)---
PortMappings = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'Mapped Ports')
AllTargoPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'TARGO Ports, Regions, Countries')
ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheetname='Data')
import pandas as pd

# =============================================================================
# targo_references = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload PRODUCT TEST.xlsx', 
#                                   sheetname='REFERENCE')
# =============================================================================

PortMappings = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'Mapped Ports')
AllTargoPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'TARGO Ports, Regions, Countries')
ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheetname='Data')
LoadPorts = pd.DataFrame(ClipperRawData['load_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
DischargePorts = pd.DataFrame(ClipperRawData['offtake_port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
AllClipperPorts = pd.DataFrame(LoadPorts.append(DischargePorts)).drop_duplicates()
MappedPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'Mapped Ports')
Mapped_Ports = pd.DataFrame(MappedPorts['ExternalValue'].str.lower()).rename(columns={'ExternalValue':'Ports'})
CurrentClipperVsMappedPorts = pd.merge(Mapped_Ports,AllClipperPorts, how='outer', indicator=True)
InMapped = CurrentClipperVsMappedPorts[CurrentClipperVsMappedPorts['_merge'] == 'left_only']
InClipper = CurrentClipperVsMappedPorts[CurrentClipperVsMappedPorts['_merge'] == 'right_only']
TargoLloydsPorts = pd.DataFrame(AllTargoPorts['name'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
TargoLloydsPorts = pd.DataFrame(AllTargoPorts['Name'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
MappedPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'Mapped Ports')
AllTargoPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'TARGO Ports, Regions, Countries')
InClipperList = InClipper['Ports']
InClipperList = pd.DataFrame(InClipper['Ports'])
TargoLloydsPorts = pd.DataFrame(AllTargoPorts['Name'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
InClipperVSLloydsList = pd.merge(InClipperList,TargoLloydsPorts, how='outer', indicator=True)
StillToBeMapped = InClipperVSLloydsList[InClipperVSLloydsList['_merge'] == 'left_only']
StillToBeMapped = InClipperVSLloydsList[InClipperVSLloydsList['_merge'] != 'both']
DirectClipperPorts = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'Direct Clipper Ports')
DirectClipperPortsList = pd.DataFrame(DirectClipperPorts['Port'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
XChckStillVsDircet = pd.merge(StillToBeMapped,DirectClipperPortsList, how='outer', indicator=True)
StillToBeMapped = InClipperVSLloydsList[InClipperVSLloydsList['_merge'] == 'left_only']
XChckStillVsDircet = pd.merge(pd.DataFrame(StillToBeMapped['Ports']),DirectClipperPortsList, how='outer', indicator=True)
UnmappedToSubregion = pd.read_excel("L:\TRADING\Targo\TargoMappingView.xlsx", sheetname = 'UNMAPPED TO SUBREGION')
UnmappedToSubregionList = pd.DataFrame(UnmappedToSubregion['Name'].str.lower().dropna().unique()).rename(columns={0:'Ports'})
XChckStillvsUnmapped =  pd.merge(pd.DataFrame(StillToBeMapped['Ports']),UnmappedToSubregionList, how='outer', indicator=True)
XChckStillvsUnmappedLeft = XChckStillvsUnmapped[XChckStillvsUnmapped['_merge'] == 'left_only']
XChckStillvsUnmappedBoth = XChckStillvsUnmapped[XChckStillvsUnmapped['_merge'] == 'both']
import pandas as pd

PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < lat+limit) &
                           (PortCoordsTEST['Latitude'] > lat-limit) &
                           (PortCoordsTEST['Longitude'] < lon+limit) &
                           (PortCoordsTEST['Longitude'] > lon-limit)
   return y

def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < lat+limit) &
                           (PortCoordsTEST['Latitude'] > lat-limit) &
                           (PortCoordsTEST['Longitude'] < lon+limit) &
                           (PortCoordsTEST['Longitude'] > lon-limit)
    return y

def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsTEST.loc[(PortCoordsTEST['Latitude'] < lat+limit) &
                           (PortCoordsTEST['Latitude'] > lat-limit) &
                           (PortCoordsTEST['Longitude'] < lon+limit) &
                           (PortCoordsTEST['Longitude'] > lon-limit)]
    return y

find_similar_ports(57,9,2)
def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsList.loc[(PortCoordsList['Latitude'] < lat+limit) &
                           (PortCoordsList['Latitude'] > lat-limit) &
                           (PortCoordsList['Longitude'] < lon+limit) &
                           (PortCoordsList['Longitude'] > lon-limit)]
    return y


find_similar_ports(57,9,2)
def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsList.loc[(PortCoordsList['Lat'] < lat+limit) &
                           (PortCoordsList['Lat'] > lat-limit) &
                           (PortCoordsList['Lon'] < lon+limit) &
                           (PortCoordsList['Lon'] > lon-limit)]
    return y


find_similar_ports(57,9,2)
def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsList.loc[(PortCoordsList['Lat'] < lat+limit) &
                           (PortCoordsList['Lat'] > lat-limit) &
                           (PortCoordsList['Long'] < lon+limit) &
                           (PortCoordsList['Long'] > lon-limit)]
    return y


find_similar_ports(57,9,2)
find_similar_ports(57,9,1)
def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsList.loc[(PortCoordsList['Lat'] < lat+limit) &
                           (PortCoordsList['Lat'] > lat-limit) &
                           (PortCoordsList['Long'] < lon+limit) &
                           (PortCoordsList['Long'] > lon-limit)]
    y = pd.DataFrame(y)
    return y


find_similar_ports(57,9,1)
import pandas as pd

PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")


def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsList.loc[(PortCoordsList['Lat'] < lat+limit) &
                           (PortCoordsList['Lat'] > lat-limit) &
                           (PortCoordsList['Long'] < lon+limit) &
                           (PortCoordsList['Long'] > lon-limit)]
    y = pd.DataFrame(y)
    return y


SimilarPorts = find_similar_ports(57,9,1)
SimilarPorts = find_similar_ports(57,9,0.5)
def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsList.loc[(PortCoordsList['Lat'] < lat+limit) &
                           (PortCoordsList['Lat'] > lat-limit) &
                           (PortCoordsList['Long'] < lon+limit) &
                           (PortCoordsList['Long'] > lon-limit)]
    #y = pd.DataFrame(y)
    return y

SimilarPorts = find_similar_ports(57,9,0.5)
SimilarPorts = find_similar_ports(57.0469,9.9366,0.2)
import pandas as pd

PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")


def find_similar_ports(lat,lon,limit):
    PortCoordsList = pd.read_excel('L:\TRADING\Targo\TargoMappingView.xlsx', sheetname="ALl Ports")
    y = PortCoordsList.loc[(PortCoordsList['Lat'] < lat+limit) &
                           (PortCoordsList['Lat'] > lat-limit) &
                           (PortCoordsList['Long'] < lon+limit) &
                           (PortCoordsList['Long'] > lon-limit)]
    y = pd.DataFrame(y)
    return y



### Enter the port coordinates below

### (lat, lon, +-limit)

SimilarPorts = find_similar_ports(57.6667,10.4167,0.2)

## ---(Fri Jan  5 17:03:25 2018)---
import eia
api = eia.API(1737754fd87b25da81a3ebbd5e3a3267)
api = eia.API('1737754fd87b25da81a3ebbd5e3a3267')
keyword_search = api.data_by_keyword(keyword=['crude oil', 'price'],
                                     filters_to_keep=['brent'],
                                     filters_to_remove=['AEO2015'],
                                     rows=1000)

for key,value in keyword_search.items():
    print(key,value)

mport pandas as pd

ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheet='Data')
import pandas as pd

ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheet='Data')
import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)
"""

import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)
import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)

## ---(Tue Jan  9 10:51:02 2018)---
import pandas as pd

DOEAPIDATA = pd.read_excel("L:\TRADING\ANALYSIS\BALANCES\US Balance v5.xlsm",
                        sheet_name="DOE_API_W", header=1, index_col = 1)
import pandas as pd

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v5.xlsm",
                        sheet_name="DOE_API_W", header=1, index_col = 1)
print(DOEAPIDATA)
import pandas as pd

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v5.xlsm",
                        sheetname="DOE_API_W", header=1, index_col = 1)
print(DOEAPIDATA)
import pandas as pd

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v5.xlsm",
                        sheetname="DOE_API_W", header=1, index_col = 1, skiprows = 1)
print(DOEAPIDATA)
import pandas as pd

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v5.xlsm",
                        sheetname="DOE_API_W", header=1, index_col = 1, skiprows = 2)

print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1, skiprows = 1)

print(DOEAPIDATA)
print(type(DOEAPIDATA))
%clear
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1)

print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1, skiprows=1)

print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1, skiprows=0)

print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1)

print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop(1)


print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop([0])


print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop([0], axis=0)


print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop([0,0])


print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop('Timestamp')


print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop('Timestamp').drop('Retrieving...', axis=1)




print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//EVERYTHING.xlsx",
                        sheetname=0, header=0)
test_path='L:/TRADING/ANALYSIS/Python/MIMA/RefineryDatabaseChecks/'
#ref_data = pd.read_excel("M://test_data_for_ref_resample.xlsx", sheetname=0, header=0)
#ref_data['Start_Date'].apply(lambda x : x.date() in ref_data['Start_Date'])
ref_data = ref_data[(ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2')]
pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)
pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')
for index, row in ref_data.iterrows():
    end_date = row[5]

for index, row in ref_data.iterrows():
    end_date = row[5]
    print(row)
    print(index)

for index, row in ref_data[20].iterrows():
    end_date = row[5]
    print(row)
    print(index)

ref_data.iterrows()
for index, row in ref_data.iterrows():

for index, row in ref_data.iterrows():
    #end_date = row[5]
    print(row)

for index, row in ref_data.iterrows():
    #end_date = row[5]
    #print(row)
    print(index)

for row in ref_data.iterrows():
    end_date = row[5]
    #print(row)
    start_date = row[4]
    name = row[1]
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]
    #ref_test_df[name] = row['CAP_OFFLINE']
    #ref_sum_df = ref_test_df.sum(axis=1).to_frame(name)

for index, row in ref_data.iterrows():
    end_date = row[5]
    #print(row)
    start_date = row[4]
    name = row[1]
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]
    #ref_test_df[name] = row['CAP_OFFLINE']

import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

ref_data = pd.read_excel("L://TRADING//ANALYSIS//REFINERY DATABASE//Latest ref sheets//Latest//EVERYTHING.xlsx",
                        sheetname=0, header=0)
test_path='L:/TRADING/ANALYSIS/Python/MIMA/RefineryDatabaseChecks/'
#ref_data = pd.read_excel("M://test_data_for_ref_resample.xlsx", sheetname=0, header=0)
#ref_data['Start_Date'].apply(lambda x : x.date() in ref_data['Start_Date'])


# =============================================================================
### slice maintenance list to include only the crude and the condensate units that we are interested in
# =============================================================================

ref_data = ref_data[(ref_data['UNIT_NAME'] == 'CRUDE #1')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #2')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #3')|
                     (ref_data['UNIT_NAME'] == 'CRUDE #4')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #1')|
                     (ref_data['UNIT_NAME'] == 'CONDENSATE DISTILLATION #2')]

#ref_data = ref_data[(ref_data['UNIT_NAME'] == 'CRUDE #1')]

### Set start and end dates for the entire dataframe
pd_index_start_date = datetime(1900, 1, 1)
pd_index_end_date = datetime(2030, 12, 1)


### define the length of the dataframe 
#total_time_period = pd_index_end_date - pd_index_start_date


### create the index by creating a list of days from the start date, 
### in days, for the duration of the time period detrmined above and 
### add one due to zero indexing
#pd_index_days_list=[pd_index_start_date + timedelta(days=x) 
#        for x in range(total_time_period.days +1)]

###ORRRRRR.......

# =============================================================================
### create a list of dates, daily, between the start and end dates
# =============================================================================

pd_index_days_list = pd.date_range(pd_index_start_date, pd_index_end_date, 
                                   freq = 'D')


# =============================================================================
### create a list of all individual refineries for column headers
# =============================================================================

ref_list=pd.Series(ref_data['REFINERY'].unique())



# =============================================================================
### create the dataframe with the col headers and index determined above
# =============================================================================

maintenance_framework = pd.DataFrame(0, index= pd_index_days_list, columns=ref_list)


# =============================================================================
### for each row in the database (each row represents a maintenance outage)
### take the start and end dates to get duration from cols 4 and 5
### get the name from column 1, then create a date range for that maintenance 
### 
# =============================================================================

for index, row in ref_data.iterrows():
    end_date = row[5]
    #print(row)
    start_date = row[4]
    name = row[1]
    #num_days_offline = end_date - start_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    ref_test_df = pd.DataFrame(row['CAP_OFFLINE'], index=date_range, columns= [row['REFINERY']])
    maintenance_framework.loc[ref_test_df.index,name]=maintenance_framework.loc[ref_test_df.index,name]+ref_test_df.loc[ref_test_df.index,name]
    #ref_test_df[name] = row['CAP_OFFLINE']

import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)


### calculate decade
d = df.index.day -1 - np.clip((df.index.day-1) // 10, 0, 2)*10
print(d)
date = df.index.values - np.array(d, dtype="timedelta64[D]")
f.groupby(date).mean()
df.groupby(date).mean()
DOEAPIDATA.index.day
import pandas as pd

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop('Timestamp').drop('Retrieving...', axis=1)
DOEAPIDATA.index.day
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col = 1).drop('Timestamp').drop('Retrieving...', axis=1)

DOEAPIDATA.index.day
DOEAPIDATA.index
maintenance_framework.index
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index = 1).drop('Timestamp').drop('Retrieving...', axis=1)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index = 1).drop('Retrieving...', axis=1)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index = 1).drop('Retrieving...', axis=1)




print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index = 0).drop('Retrieving...', axis=1)




print(DOEAPIDATA)
print(type(DOEAPIDATA))
%clear
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index = 0).drop('Retrieving...', axis=1)




print(DOEAPIDATA)
print(type(DOEAPIDATA))
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1).drop('Retrieving...', axis=1)

import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1).drop('Retrieving...', axis=1)




print(DOEAPIDATA)
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1).drop('Retrieving...', axis=1)




print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =0).drop('Retrieving...', axis=1)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =0)




print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =1)




print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =1).drop(columns=0)




print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =1).drop(columns=[0])




print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =1)




print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =1).drop(['Timestamp'])




print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.index.day
import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)
df.index.day
DOEAPIDATA = pd.DataFrame(DOEAPIDATA)
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1, index_col =1).drop(['Timestamp'])
DOEAPIDATA = pd.DataFrame(DOEAPIDATA, index=0)
DOEAPIDATA.index.day
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header=1)


#DOEAPIDATA = pd.DataFrame(DOEAPIDATA, index=0)



print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
                        sheetname="DOE_API_W", header=1)
DOEAPIDATA.loc[:,1]
DOEAPIDATA.loc[:,1]
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W")
DOEAPIDATA
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)
DOEAPIDATA
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)



#DOEAPIDATA = pd.DataFrame(DOEAPIDATA, index=0)



print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Timestamp'])

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Timestamp'], axis=0)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop[0]

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
@author: mima
"""

import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'])

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'], axis = 1)

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'], axis = 1)
DOEAPIDATA.set_index(DOEAPIDATA['Unnamed: 1'])

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)

df.describe()
df.dtypes()
df.dtypes
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'], axis = 1)


print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtype
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'], axis = 1)


print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = DOEAPIDATA.convert_objcts(convert_numeric=True)


print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
@author: mima
"""

import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = DOEAPIDATA.convert_objects(convert_numeric=True)


print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = DOEAPIDATA.convert_objects(convert_numeric=True)


print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
DOEAPIDATA.index.day
DOEAPIDATA
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop([0]).drop(['Retrieving...'], axis = 1)
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1)
DOEAPIDATA
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = DOEAPIDATA.convert_objects(convert_numeric=True)


print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = pd.to_numeric(DOEAPIDATA)
DOEAPIDATA = DOEAPIDATA.convert_objects(convert_numeric=True)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = DOEAPIDATA.convert_objects(convert_numeric=True)


print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA.dtypes
DOEAPIDATA.index.day
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1)
DOEAPIDATA
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)
DOEAPIDATA
DOEAPIDATA.index.day
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA.index.day
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
d
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA.apply(pd.to_numeric)

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
#DOEAPIDATA = pd.DataFrame(DOEAPIDATA, index=0)






d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date).mean()
DOEAPIDATA.apply(partial(pd.to_numeric, errors='ignore')).info()
DOEAPIDATA.apply(pd.to_numeric, errors='ignore').info()
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA.apply(pd.to_numeric, errors='ignore').info()

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
#DOEAPIDATA = pd.DataFrame(DOEAPIDATA, index=0)






d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1, dtype=float).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = DOEAPIDATA.astype(float)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = DOEAPIDATA.astype(float).info()
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = DOEAPIDATA.astype(float).info()
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)
DOEAPIDATA = DOEAPIDATA.astype(float).info()
DOEAPIDATA
print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)
DOEAPIDATA.astype(float).info()
DOEAPIDATA
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA.index.day
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date).mean()
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date1 = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date1).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, index_col = 1, dtype=float).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, dtype=float).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0, dtype=float)
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)
DOEAPIDATA
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Timestamp']).drop(['Retrieving...'], axis = 1)
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)
DOEAPIDATA
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Retrieving...'], axis = 1).drop(['Timestamp'])
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Retrieving...'], axis = 1)
DOEAPIDATA
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Retrieving...'], axis = 1)

DOEAPIDATA = DOEAPIDATA.astype(float).info()
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Retrieving...'], axis = 1)
DOEAPIDATA
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Retrieving...'], axis = 1).drop([0])
DOEAPIDATA
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(['Retrieving...'], axis = 1).drop([0])
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)
DOEAPIDATA
print(DOEAPIDATA.head())
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0], axis = 1).drop([0])
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop(0, axis = 1).drop([0])
DOEAPIDATA
print(DOEAPIDATA.head())
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])
print(DOEAPIDATA.head())
DOEAPIDATA.columns[1]
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(DOEAPIDATA.columns[0])
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)
DOEAPIDATA
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])
print(DOEAPIDATA.head())
DOEAPIDATA.drop(DOEAPIDATA.columns[0])
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA
DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
print(DOEAPIDATA.head())
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date1 = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date1).mean()
DOEAPIDATA.dtypes
DOEAPIDATA.apply(pd.to_numeric, errors='ignore').info()
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date1 = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date1).mean()
print(DOEAPIDATA.head())
DOEAPIDATA.dtypes
DOEAPIDATA = DOEAPIDATA.apply(pd.to_numeric, errors='ignore').info()
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date1 = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date1).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).drop(DOEAPIDATA.columns[0], axis=1)

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)
DOEAPIDATA = DOEAPIDATA.drop([0]).drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = DOEAPIDATA.apply(pd.to_numeric, errors='ignore').info()
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])
DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)

df.dtypes

DOEAPIDATAnum = DOEAPIDATA.apply(pd.to_numeric).info()
d = DOEAPIDATAnum.index.day -1 - np.clip((DOEAPIDATAnum.index.day-1) // 10, 0, 2)*10
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date1 = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby().mean()
DOEAPIDATA.groupby(date1).mean()
print(date1)
DOEAPIDATA.index.day
import pandas as pd
import numpy as np

begin = pd.datetime(2013,1,1)
end = pd.datetime(2013,2,20)

dtrange = pd.date_range(begin, end)

p1 = np.random.rand(len(dtrange)) + 5
p2 = np.random.rand(len(dtrange)) + 10

df = pd.DataFrame({'p1': p1, 'p2': p2}, index=dtrange)

df.dtypes


### calculate decade
d = df.index.day -1 - np.clip((df.index.day-1) // 10, 0, 2)*10
date = df.index.values - np.array(d, dtype="timedelta64[D]")
df.groupby(date).mean()

print(d)

###  What lines 23-25 mean
### we created an index od dtranges bages betweendays as values
print(df.index.day)

### zero-indexing adjustment
print(df.index.day-1)

### divisor and rounded down to nearest whole for 1st, 2nd and 3rd
print((df.index.day-1) // 10)

### numpy's clip takes our array and clips to whole numbers betwen 0 and 2 for 1st, 2bd, 3rd
print(np.clip((df.index.day-1) // 10, 0, 2))
df.index.day
mike = DOEAPIDATA.resample('d').mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0]).set_index('Date')


DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)

DOEAPIDATA = DOEAPIDATA.set_index('Date')


DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)

DOEAPIDATAnum = DOEAPIDATA.apply(pd.to_numeric).info()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])
DOEAPIDATA = DOEAPIDATA.set_index('Date')
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATAnum = DOEAPIDATA.apply(pd.to_numeric, errors='coerce').info()
DOEAPIDATA.groupby(date1).mean()
DOEAPIDATA = DOEAPIDATA.dropna(axis=0, how = 'any')
DOEAPIDATAnum = DOEAPIDATA.apply(pd.to_numeric, errors='coerce').info()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])
DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
#DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
#DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)


#DOEAPIDATA = DOEAPIDATA.dropna(axis=0, how = 'any')
DOEAPIDATA = DOEAPIDATA.apply(pd.to_numeric, errors='coerce').info()
DOEAPIDATA.groupby(date1).mean()
DOEAPIDATA = pd.DataFrame(DOEAPIDATA)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
#DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
DOEAPIDATA.dtypes
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date1 = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
DOEAPIDATA.groupby(date1).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
#DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
d = DOEAPIDATA.index.day -1 - np.clip((DOEAPIDATA.index.day-1) // 10, 0, 2)*10
date1 = DOEAPIDATA.index.values - np.array(d, dtype="timedelta64[D]")
decade_DOEAPIDATA = DOEAPIDATA.groupby(date1).mean()
DOEAPIDATA.index.day
mike = DOEAPIDATA.resample('d').mean()
mike = DOEAPIDATA.resample('d').ffill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
print(date1)
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
#DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)


#DOEAPIDATA = DOEAPIDATA.dropna(axis=0, how = 'any')
#DOEAPIDATA = DOEAPIDATA.apply(pd.to_numeric, errors='coerce').info()
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)

print(DOEAPIDATA.head())
print(type(DOEAPIDATA))
DOEAPIDATA.dtypes
#DOEAPIDATA = pd.DataFrame(DOEAPIDATA, index=0)



mike = DOEAPIDATA.resample('d').bfill()


d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("M://DOE TEST SHEET.xlsx",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v6.xlsm",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v6.xlsm",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    print(d)

df=pd.DataFrame(d)
df['Data'][0]
df['data'][0]
df['data'].iloc[0]
df['data'].iloc[:,0]
df['data'].loc[:,0]
df['data']
df['data'][2:4]
df['data'][2:9]
df['data'][:][0]
df['data']
x = df['data']
df['Date'] = [row[0] for row in df['data']]
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]


connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=EIAData; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO Series"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]


connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=EIAData; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO Series"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]


connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
Values.dtype
Values.dtype()
Values[0].dtype()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

df = pd.DataFrame(df).astype(float)


connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
df["last_updated"].dtype()
df.dtype()
df.dtype
df.dtypes
df["last_updated"].dtypes
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     
#
#cursor = connection.cursor()
#SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
#          "VALUES (?,?,1,?,?,?)")
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
#cursor.execute(SQLCommand,Values)
#connection.commit()
#connection.close()

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id) "
          "VALUES (?)")
Values = df["series_id"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")     

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = [1,1,1,1,1]
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")   

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = [1,1,1,1,1]
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")  
cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = [1,1,1,1,1]
cursor.execute(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")   

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = [1,1,1,1,1]
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")   

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

#Values = [1,1,1,1,1]
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
#
df["series_id"].tolist
df["series_id"].tolist()
Values = df["series_id"].tolist(), df["name"].tolist(), df["f"].tolist(), df["units"].tolist(), df["last_updated"].tolist()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")   

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

#Values = [1,1,1,1,1]
Values = df["series_id"].tolist(), df["name"].tolist(), df["f"].tolist(), df["units"].tolist(), df["last_updated"].tolist()
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")   

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

#Values = [1,1,1,1,1]
Values = [df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
Values
Values.head()
Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
Values.head()
type(Values)
Values
type(Values)
type(df["series_id"])
Values[0]
print(Values)
dfSQL = list(zip(df.Series_id, df.name))
dfSQL = list(zip(df.series_id, df.name))
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")   

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(series_id, Name, CategoryId, f, Units, updated) "
          "VALUES (?,?,1,?,?,?)")

#Values = [1,1,1,1,1]
Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]

#df.dtypes
#df = pd.DataFrame(df).astype(float)

#df["last_updated"].dtypes
#
#connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")   

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(Id, Name, CategoryId, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

#Values = [1,1,1,1,1]
Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated))[0] 
Values
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v6.xlsm",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()

import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v7.xlsm",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()
DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v7.xlsm",
                        sheetname="DOE_API_W", header =0)
DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v7.xlsm",
                        sheetname="DOE_API_W", header =0).drop([0])
DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()
DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta 

DOEAPIDATA = pd.read_excel("L://TRADING//ANALYSIS//BALANCES//US Balance v7.xlsm",
                        sheetname="DOE_API_W", header =0).drop([0])

DOEAPIDATA = DOEAPIDATA.set_index('Date')
DOEAPIDATA = DOEAPIDATA.drop(DOEAPIDATA.columns[0], axis=1)
DOEAPIDATA.index = pd.to_datetime(DOEAPIDATA.index)
DOEAPIDATA = pd.DataFrame(DOEAPIDATA).astype(float)
mike = DOEAPIDATA.resample('d').bfill()
d = mike.index.day -1 - np.clip((mike.index.day-1) // 10, 0, 2)*10
date1 = mike.index.values - np.array(d, dtype="timedelta64[D]")
decade_mike = mike.groupby(date1).mean()
writer = pd.ExcelWriter("M://DOE TEST SHEET.xlsx")
decade_mike.to_excel(writer, 'DOE_API_Dec')
writer.save()
df['Newdate'] = [row[0]+"01" for row in df['Date'] if len(df['Date']) <8 ]
with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row[0]+"01" for row in df['Date'] if len(df['Date']) <8 ]
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row[0]+"01" for row in df['Date'] if len(df['Date']) <8 ]
df['Newdate'] = [row[0]+"01" for row in df['Date']]
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['data']
df['Date']
import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

df=pd.DataFrame(d)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)
        df = pd.DataFrame(d)

from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)
        df = pd.DataFrame(d)

from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)
        df = pd.DataFrame(d)

from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)
        df = pd.DataFrame(d)

from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)
        df = pd.DataFrame(d)

f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r')
f
f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r').read()

## ---(Wed Jan 10 19:05:21 2018)---
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []

f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r')
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []

f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r').read()

## ---(Wed Jan 10 19:09:33 2018)---
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f

with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:

open('L:\\TRADING\SQLDataUpload\PET.txt') as f
open('L:\\TRADING\SQLDataUpload\PET.txt')
f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r')
f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r')
print(f)
f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r').read()
print(f)

## ---(Wed Jan 10 19:14:02 2018)---
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)
        df = pd.DataFrame(d)

i = 0
data = []

f = open('L:\\TRADING\SQLDataUpload\PET.txt', 'r')

with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)
        df = pd.DataFrame(d)

import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

import json 
import pandas as pd
import pyodbc

with open('L:\\TRADING\SQLDataUpload\PETTest.txt') as json_data:
    d = json.load(json_data)
    seriesd = d['data']
    print(d)

import json 
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r')
json_data
import json 
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
attempt = pd.read_json(d)
json_try = json_data.to_json()
json_data =  pd.DataFrame(open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read())
json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
json_data = pd.DataFrame(json_data)
import json 
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
json_try = json_data.to_json(json_data)
df = pd.read_json(json_data)
import json 
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
import json 
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]
import json 
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1].astype(float) for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]
row[1]
df.types
df.types()
df.type()
df.dtypes()
df.dtypes
import json 
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]

df.dtypes
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated))[0] 
df['Newdate'] = pd.to_datetime(df['Newdate'], format=%Y%m%d)
new_date = datetime.strptime(df['Newdate'], '%YYYY%mm%dd'
new_date = datetime.strptime(df['Newdate'], '%YYYY%mm%dd')
import json 
import pandas as pd
import pyodbc
from datetime import datetime

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]

new_date = datetime.strptime(df['Newdate'], '%YYYY%mm%dd')
mike = [datetime.strptime(row,'%YYYY%mm%dd') for row in df['Newdate']]
mike = [datetime.strptime(row,'%Y%m%d') for row in df['Newdate']]
mike = [datetime.strptime(row,'%Y%m%d').strftime('%d-%m-%Y') for row in df['Newdate']]
import json 
import pandas as pd
import pyodbc
from datetime import datetime

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]

### first we need to take the string and turn that into a datime object and then create a string from the datetime in our format
df['mike'] = [datetime.strptime(row,'%Y%m%d').strftime('%d-%m-%Y') for row in df['Newdate']]
df.columns
Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated))[0] 
df.dtypes
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated))[0] 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EIASeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
cursor.executemany(SQLCommand,Values)
connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)

connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise

df.dtypes
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, str(df.last_updated))) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units) "
          "VALUES (?,?,1,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()


df["last_updated"]
df["last_updated"].strftime('%d-%m-%Y')
mike1 = datetime.strptime(df["last_updated"],'%Y-%m-%d').strftime('%d-%m-%Y')
df["last_updated"].dtype
str(df["last_updated"]).dtype
str(df["last_updated"])
df["last_updated"][0:11]
mike1 = datetime.strptime('2018-01-04T14:44:31-05:00','%Y-%m-%d').strftime('%d-%m-%Y')
mike1
mike1 = datetime.strptime('2018-01-04T14:44:31-05:00','%Y-%m-%d').strftime('%d-%m-%Y').date()
mike1 = datetime.strptime('2018-01-04T14:44:31-05:00','%Y-%m-%d %H:%M:%S').strftime('%d-%m-%Y').date()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, str(df.last_updated)) )
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, str(df.last_updated)) )
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, str(df.last_updated.split('T')[0])) )
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()
connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, str(df.last_updated).split('T')[0])) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()

Values = list(zip(df.series_id, df.name, df.f, df.units, str(df.last_updated).split('T')[0])) 
Values
df['last_updated2'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') for row in df['last_updated']]
import json 
import pandas as pd
import pyodbc
from datetime import datetime
import dateutil.parser
df['last_updated2'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') for row in df['last_updated']]
import json 
import pandas as pd
import pyodbc
from datetime import datetime
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]

### first we need to take the string and turn that into a datime object and then create a string from the datetime in our format
df['mike'] = [datetime.strptime(row,'%Y%m%d').strftime('%d-%m-%Y') for row in df['Newdate']]
df['last_updated2'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') for row in df['last_updated']]
df.columns
mike1 = datetime.strptime('2018-01-04T14:44:31-05:00','%Y-%m-%d %H:%M:%S').strftime('%d-%m-%Y').date()



df.dtypes

df["last_updated"][0:11]

str(df["last_updated"])


connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated2)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()
import json 
import pandas as pd
import pyodbc
from datetime import datetime
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
#json_data = pd.DataFrame(json_data)
#json_try = json_data.to_json(json_data)

df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]

### first we need to take the string and turn that into a datime object and then create a string from the datetime in our format
df['mike'] = [datetime.strptime(row,'%Y%m%d').strftime('%d-%m-%Y') for row in df['Newdate']]
df['last_updated2'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') for row in df['last_updated']]
df.columns




df.dtypes

df["last_updated"][0:11]

str(df["last_updated"])


connection = pyodbc.connect("Driver={SQL Server}; Server=STUKLS022; Database=TradeTracker; uid=GAMI ;pwd=pw;Trusted_Connection=yes")    

cursor = connection.cursor()
SQLCommand = ("INSERT INTO EiaSeriesTest"  "(Id, Name, CategoryID, f, units, updated) "
          "VALUES (?,?,1,?,?,?)")

Values = list(zip(df.series_id, df.name, df.f, df.units, df.last_updated2)) 
#Values = df["series_id"], df["name"], df["f"], df["units"], df["last_updated"]
try:
    cursor.executemany(SQLCommand,Values)
except:
    print(Values)
    raise


connection.commit()
connection.close()



import json 
import pandas as pd
import pyodbc
from datetime import datetime
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['Newdate'] = [row+"01" if len(row) <8 else row for row in df['Date']]
df['mike'] = [datetime.strptime(row,'%Y%m%d').strftime('%d-%m-%Y') 
                                    for row in df['Newdate']]
df['last_updated2'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]
d = json.loads(line)
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)

from datetime import datetime, time 
import json
import pandas as pd
import pyodbc


i = 0
data = []
with open('L:\\TRADING\SQLDataUpload\PET.txt') as f:
    for line in f:
        i = i + 1
        d = json.loads(line)

Values = list(zip(df.series_id,  
                  pd.to_datetime(df['Newdate'], format='%Y%m%d'),
                  df['Amount'].astype(float)))
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [row[0] for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [row[0]+"01" for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d') for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d') if len(row) <8 else
          datetime.strptime(row[0], '%Y%m%d') for row in df['data']]
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d') if len(row) <8 else
          datetime.strptime(row[0], '%Y%m%d') for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d') if len(row) <8 else
          datetime.strptime(row[0], '%Y%m%d') for row in df['data']]
df['Amount'] = [row[1] for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if 
                len(row) <8 
                else
                datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row in df['data']]
df['Amount'] = [row[1].astype(float) for row in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if len(row) <8 
                else datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row 
                in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]


#connection = pyodbc.connect('''Driver={SQL Server}; 
#                            Server=STUKLS022; 
#                            Database=EIAData; 
#                            uid=GAMI ;
#                            pwd=pw;
#                            Trusted_Connection=yes''')    

connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO EIA Series Test"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))

cursor.executemany(SQLCommand,Values)

SQLCommand = (
            "INSERT INTO SeriesData"  
            "(series_id, Period, Value ) "
            "VALUES (?,?,?)"
              )

Values = list(zip(df.series_id,  
                  df.Date,
                  df.Amount))

cursor.executemany(SQLCommand,Values)


SQLCommand = (
            "INSERT INTO Category Test"  
            "(id, Name, ParentID) "
             "VALUES (?,?,?)"
             )

Values = list(zip(df.category_id, 
                  df.name, 
                  df.parent_category_id ))

cursor.execute(SQLCommand,Values)
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if len(row) <8 
                else datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row 
                in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]


#connection = pyodbc.connect('''Driver={SQL Server}; 
#                            Server=STUKLS022; 
#                            Database=EIAData; 
#                            uid=GAMI ;
#                            pwd=pw;
#                            Trusted_Connection=yes''')    

connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))

cursor.executemany(SQLCommand,Values)

SQLCommand = (
            "INSERT INTO SeriesData"  
            "(series_id, Period, Value ) "
            "VALUES (?,?,?)"
              )

Values = list(zip(df.series_id,  
                  df.Date,
                  df.Amount))

cursor.executemany(SQLCommand,Values)


SQLCommand = (
            "INSERT INTO Category"  
            "(id, Name, ParentID) "
             "VALUES (?,?,?)"
             )

Values = list(zip(df.category_id, 
                  df.name, 
                  df.parent_category_id ))

cursor.execute(SQLCommand,Values)
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if len(row) <8 
                else datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row 
                in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]


#connection = pyodbc.connect('''Driver={SQL Server}; 
#                            Server=STUKLS022; 
#                            Database=EIAData; 
#                            uid=GAMI ;
#                            pwd=pw;
#                            Trusted_Connection=yes''')    

connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))

cursor.executemany(SQLCommand,Values)

SQLCommand = (
            "INSERT INTO SeriesData"  
            "(series_id, Period, Value ) "
            "VALUES (?,?,?)"
              )

Values = list(zip(df.series_id,  
                  df.Date,
                  df.Amount))

cursor.executemany(SQLCommand,Values)


SQLCommand = (
            "INSERT INTO Category"  
            "(id, Name, ParentID) "
             "VALUES (?,?,?)"
             )

Values = list(zip(df.series_id, 
                  df.name, 
                  df.description ))

cursor.execute(SQLCommand,Values)
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if len(row) <8 
                else datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row 
                in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]


#connection = pyodbc.connect('''Driver={SQL Server}; 
#                            Server=STUKLS022; 
#                            Database=EIAData; 
#                            uid=GAMI ;
#                            pwd=pw;
#                            Trusted_Connection=yes''')    

connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))

cursor.executemany(SQLCommand,Values)

SQLCommand = (
            "INSERT INTO SeriesData"  
            "(series_id, Period, Value ) "
            "VALUES (?,?,?)"
              )

Values = list(zip(df.series_id,  
                  df.Date,
                  df.Amount))

cursor.executemany(SQLCommand,Values)


SQLCommand = (
            "INSERT INTO Category"  
            "(id, Name, ParentID) "
             "VALUES (?,?,?)"
             )

Values = list(zip(df.series_id, 
                  df.name, 
                  df.description ))

cursor.executemany(SQLCommand,Values)

connection.commit()
connection.close()
Values = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
Values
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
Values
"""
Created on Thu Jan 11 09:37:29 2018

@author: mima
"""

from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if len(row) <8 
                else datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row 
                in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]


#connection = pyodbc.connect('''Driver={SQL Server}; 
#                            Server=STUKLS022; 
#                            Database=EIAData; 
#                            uid=GAMI ;
#                            pwd=pw;
#                            Trusted_Connection=yes''')    

connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))

cursor.executemany(SQLCommand,Values)

SQLCommand = (
            "INSERT INTO SeriesData"  
            "(series_id, Period, Value ) "
            "VALUES (?,?,?)"
              )

Values = set(list(zip(df.series_id,  
                  df.Date,
                  df.Amount)))

cursor.executemany(SQLCommand,Values)


SQLCommand = (
            "INSERT INTO Category"  
            "(id, Name, ParentID) "
             "VALUES (?,?,?)"
             )

Values = set(list(zip(df.series_id, 
                  df.name, 
                  df.description )))

cursor.executemany(SQLCommand,Values)

connection.commit()
connection.close()
Values = set(list(zip(df.series_id,  
                  df.Date,
                  df.Amount)))
len(Values)
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
len(Values)
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))

[cursor.executemany(SQLCommand,Values) if len(Values) > 1 else cursor.execute(SQLCommand,Values)]


SQLCommand = (
            "INSERT INTO SeriesData"  
            "(series_id, Period, Value ) "
            "VALUES (?,?,?)"
              )

Values = set(list(zip(df.series_id,  
                  df.Date,
                  df.Amount)))

[cursor.executemany(SQLCommand,Values) if len(Values) > 1 else cursor.execute(SQLCommand,Values)]


SQLCommand = (
            "INSERT INTO Category"  
            "(id, Name, ParentID) "
             "VALUES (?,?,?)"
             )

Values = set(list(zip(df.series_id, 
                  df.name, 
                  df.description )))

[cursor.executemany(SQLCommand,Values) if len(Values) > 1 else cursor.execute(SQLCommand,Values)]

connection.commit()
connection.close()
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
if len(Values) >1:
    cursor.executemany(SQLCommand,Values)
else:
    cursor.execute(SQLCommand,Values)

Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
Values
cursor.executemany(SQLCommand,Values)
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
cursor.executemany(SQLCommand,Values)
cursor.execute(SQLCommand,Values)
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
Values
zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)
Values = list(set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
Values = list(set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
if len(Values) >1:
    cursor.executemany(SQLCommand,Values)
else:
    cursor.execute(SQLCommand,Values)

connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
cursor.execute(SQLCommand,Values)
Values
Values = set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
Values
cursor.execute(SQLCommand,Values)
Values = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
Values
cursor.execute(SQLCommand,Values)
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
cursor.executemany(SQLCommand,Values)
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
Values
Values = set(list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))[0]
Values = list(set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))
cursor.execute(SQLCommand,Values)
Values1 = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
cursor.execute(SQLCommand,Values1)
cursor.execute(SQLCommand,Values)
Values = list(set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))[0]
cursor.execute(SQLCommand,Values)
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
Values = list(set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)))[0]
if len(Values) >1:
    cursor.executemany(SQLCommand,Values1)
else:
    cursor.execute(SQLCommand,Values)

connection.commit()
connection.close()
set(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)
Values = zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated)
Values
print(Values)
Values = (zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
print(Values)
connection.close()

## ---(Thu Jan 11 11:24:31 2018)---
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if len(row) <8 
                else datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row 
                in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]
df_test = pd.concat([f.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1)
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1)
df_test = df_test.unique()
df_test = df_test.unique
df_test = df_test.drop_duplicates()
df_test = df_test.drop_duplicates().values.tolist()
Values1 = list(zip(df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated))
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()
SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
cursor.execute(SQLCommand,df_test)
df_test = df_test.drop_duplicates().values
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1)
df_test = df_test.drop_duplicates().values
cursor.execute(SQLCommand,df_test)
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1)

df_test = list(df_test.drop_duplicates().values)
cursor.execute(SQLCommand,df_test)
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1)
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1).to_list()
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1).to_list
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1).tolist()
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1).values.tolist()
cursor.executemany(SQLCommand,df_test)
connection.commit()
connection.close()
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1).values.drop_duplicates.tolist()
df_test = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1).drop_duplicates().values.tolist()
cursor.executemany(SQLCommand,df_test)
connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()

SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )
cursor.executemany(SQLCommand,df_test)
connection.commit()
connection.close()
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PETTest.txt','r').read()
df = pd.read_json(json_data)
df['Date'] = [datetime.strptime((row[0]+"01"), '%Y%m%d').strftime('%d-%m-%Y')
                if len(row) <8 
                else datetime.strptime(row[0], '%Y%m%d').strftime('%d-%m-%Y')
                for row 
                in df['data']]
df['Amount'] = [float(row[1]) for row in df['data']]
df['last_updated'] = [dateutil.parser.parse(row).strftime('%d-%m-%Y') 
                                    for row in df['last_updated']]


#connection = pyodbc.connect('''Driver={SQL Server}; 
#                            Server=STUKLS022; 
#                            Database=EIAData; 
#                            uid=GAMI ;
#                            pwd=pw;
#                            Trusted_Connection=yes''')    

connection = pyodbc.connect('''Driver={SQL Server}; 
                            Server=STCHGS112; 
                            Database=MIMAWorkSpace; 
                            uid=MIMA ;
                            pwd=pw;
                            Trusted_Connection=yes''')    

cursor = connection.cursor()

SQLCommand = (
            "INSERT INTO Series"  
            "(id, Name, CategoryId, f, Units, updated) "
            "VALUES (?,?,1,?,?,?)"
             )

Values = pd.concat([df.series_id,
                  df.name,
                  df.f,
                  df.units, 
                  df.last_updated], axis = 1).drop_duplicates().values.tolist()

cursor.executemany(SQLCommand,Values)

SQLCommand = (
            "INSERT INTO SeriesData"  
            "(series_id, Period, Value ) "
            "VALUES (?,?,?)"
              )

Values = pd.concat([df.series_id,  
                  df.Date,
                  df.Amount], axis = 1).drop_duplicates().values.tolist()

cursor.executemany(SQLCommand,Values)

SQLCommand = (
            "INSERT INTO Category"  
            "(id, Name, ParentID) "
             "VALUES (?,?,?)"
             )


Values = pd.concat([df.series_id, 
                  df.name, 
                  df.description], axis = 1).drop_duplicates().values.tolist()

cursor.executemany(SQLCommand,Values)

connection.commit()
connection.close()
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PET.txt','r').read()
df = pd.read_json(json_data)
json_data =  open('L:\\TRADING\SQLDataUpload\PET.txt','r').read()
json_data.head()
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

json_data =  open('L:\\TRADING\SQLDataUpload\PET.txt','r').read()
df = pd.read_json(json_data)
df.head()
from datetime import datetime, time 
import json
import pandas as pd
import pyodbc
import dateutil.parser

#json_data =  open('L:\\TRADING\SQLDataUpload\PET.txt','r').read()

df = pd.read_json('L:\\TRADING\SQLDataUpload\PET.txt', lines=True)
df['data']
df[145616]
df.loc[145616]
df.head()
df['category_id']
category_id = df['category_id']
category_id = df['category_id'][139158]
category_id = df['category_id'][139168]
from pandas.io.json import json_normalize
lol = json_normalize(df)
json_normalize(df)
df.loc[145616]
df.loc[145]
farm = df[df['series_id' == PET.KDRVAFNUS1.A]]
farm = df[df['series_id' == 'PET.KDRVAFNUS1.A']]
farm = df[df['series_id'] == 'PET.KDRVAFNUS1.A']
farm = df[df['category_id'] == 235678]
farm = df[df['parent_category_id'] == 235678]
farm = df[df['series_id'] == 'PET.WCRFPUS2.4']
farm = df[df['series_id'] == 'PET.WCRFPUS2.w']
farm = df[df['series_id'] == 'PET.WCRFPUS2.W']
farm = df[df['category_id'] == 235678]
import pandas
ClipperRawData = pd.read_excel("L:\TRADING\ANALYSIS\Clipper Ship Tracking Analysis\Clipper Data\Clipper Global Crude Full History.xlsm", sheet='Data')

## ---(Mon Jan 22 17:08:08 2018)---
import pandas as pd
import numpy as np


med_data = pd.read_excel('L:\TRADING\ANALYSIS\Python\MIMA\InputTargoStuff\TARGO Upload History Med with Validation V2.xlsx')
grade_list med_data['Grade'].unique()
grade_list = med_data['Grade'].unique()
grade_list = med_data['Grade'].unique
grade_list = med_data['Grade'].unique
print(grade_list)
grade_list = med_data['Grade'].unique()
print(grade_list)
[conditions_cpc if med_data['Grade'] == 'CPC' else conditions_other]
[conditions_cpc if med_data['Grade'] == 'CPC' else conditions_other in med_data['Grade']]
['1' for row in med_data['Grade'] if med_data['Grade'] == 'CPC' else '2' ]
[print('1') for row in med_data['Grade'] if med_data['Grade'] == 'CPC' else '2' 
[print('1') if med_data['Grade'] == 'CPC' else print('2') for row in med_data['Grade'] ]
med_data['Grade']
print('1') if med_data['Grade'] == 'CPC'
[print('1') if med_data['Grade'] == 'CPC' else print('2') for row in med_data['Grade']
[print('1') if med_data['Grade'] == 'CPC' else print('2') for row in med_data['Grade'] ]
print('1') if (med_data['Grade'] == 'CPC') else print('2') for row in med_data['Grade'] ]
[print('1') if (med_data['Grade'] == 'CPC') else print('2') for row in med_data['Grade'] ]
med_data['Grade'] == 'CPC'
print('2')
print('1') if (med_data['Grade'] == 'CPC') else print('2')
print('2')
print('1')
(med_data['Grade'] == 'CPC')
med_data['Grade']
row
[print('1') if (med_data[med_data['Grade'] == 'CPC']) else print('2') for row in med_data['Grade'] ]
(med_data[med_data['Grade'] == 'CPC']
(med_data[med_data['Grade'] == 'CPC'])
[print('1') if row == 'CPC' else print('2') for row in med_data['Grade'] ]
def standardise_cargo_size(i):
    [replacement for condition, replacement in [conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade'] ]]

ar = map(standardise_cargo_size, med_data['Quantity'])
ar
print(ar)    
standardise_cargo_size(med_data['Quantity'])
conditions_other = [(lambda i: i < 300, 250),
                    (lambda i: 300 <= i  < 400, 315),
                    (lambda i: 400 <= i < 500, 450),
                    (lambda i: 500 <= i < 600, 510),
                    (lambda i: 600 <= i < 700, 630),
                    (lambda i: 700 <= i < 900, 750),
                    (lambda i: 900 <= i <= 1200, 1020),
                    (lambda i: i > 1200, 2050)]

conditions_cpc = [(lambda i: i < 500, 330),
                  (lambda i: 500 <= i < 600, 535),
                  (lambda i: 600 <= i < 720, 670),
                  (lambda i: 720 <= i <= 760, 760)]
def standardise_cargo_size(i):
    [replacement for condition, replacement in [conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade'] ]]

ar = map(standardise_cargo_size, med_data['Quantity'])
print(ar)  
standardise_cargo_size(med_data['Quantity'])
def standardise_cargo_size2(i):
    for condition, replacement in conditions_other:
        if conbdition(i):
            return replacement
    return i

med_data['Quantity']
ar = map(standardise_cargo_size2, med_data['Quantity'])
print(ar)
ar = list(map(standardise_cargo_size2, med_data['Quantity']))
for condition, replacement in conditions_other:
    if condition(i):
        return replacement

return i
ar = list(map(standardise_cargo_size2, med_data['Quantity']))
def standardise_cargo_size2(i):
    for condition, replacement in conditions_other:
        if condition(i):
            return replacement
    return i

ar = list(map(standardise_cargo_size2, med_data['Quantity']))
def standardise_cargo_size(i):
    [replacement for condition, replacement in [conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']]]

ar = list(map(standardise_cargo_size, med_data['Quantity']))
def standardise_cargo_size2(i):
    for condition, replacement in conditions_other:
        if condition(i):
            return replacement
    return i

ar = list(map(standardise_cargo_size2, med_data['Quantity']))
def standardise_cargo_size(i):
    return [replacement for condition, replacement in [conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']]]



ar = list(map(standardise_cargo_size, med_data['Quantity']))
[conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']]
def standardise_cargo_size(i):
    return [replacement for condition, replacement in 
            [conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']] if condition(i)]

ar = list(map(standardise_cargo_size, med_data['Quantity']))
[replacement for condition, replacement in 
        [conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']] if condition(i)]
def standardise_cargo_size(i):
    return [replacement for condition(i), replacement in 
            [conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']]]

[conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']]
def standardise_cargo_size(i):
    return [replacement for condition, replacement in 
            [conditions_cpc(i) if row == 'CPC' else conditions_other(i) for row in med_data['Grade']]]

ar = list(map(standardise_cargo_size, med_data['Quantity']))
map(standardise_cargo_size, med_data['Quantity'])
standardise_cargo_size
ar = map(standardise_cargo_size, med_data['Quantity'])
ar = map(standardise_cargo_size, med_data['Quantity'])

print(ar)
ar = list(map(standardise_cargo_size, med_data['Quantity']))
ar = pd.Series(map(standardise_cargo_size, med_data['Quantity']))
def standardise_cargo_size(i):
     [replacement for condition, replacement in 
            [conditions_cpc(i) if row == 'CPC' else conditions_other(i) for row in med_data['Grade']]]

ar = pd.Series(map(standardise_cargo_size, med_data['Quantity']))
[conditions_cpc(i) if row == 'CPC' else conditions_other(i) for row in med_data['Grade']]
def standardise_cargo_size(i):
     [replacement for condition, replacement in 
            [conditions_cpc(i) if row == 'CPC' else conditions_other(i) for row in med_data['Grade']]]

standardise_cargo_size(200) 
[conditions_cpc if row == 'CPC' else conditions_other for row in med_data['Grade']]
print(grade_list)
def standardise_cargo_size(i):
     [replacement for condition, replacement in 
            [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]

[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
def standardise_cargo_size_attempt(i):
     [replacement for condition(i), replacement in 
            [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]

def standardise_cargo_size(i):
     [replacement for i, replacement in 
            [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]

standardise_cargo_size(med_data['Quantity'])
def standardise_cargo_size(i):
     [replacement for i, replacement in 
            [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]

[replacement for i, replacement in 
       [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
[replacement for i, replacement in 
       [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
def standardise_cargo_size_attempt(i):
     [replacement for condition, replacement in 
            [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']](i)]

standardise_cargo_size(med_data['Quantity'])
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']](i)
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']](600)
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']
[i for condition, replacement in conditions_other if condition(i)]
[replacement for condition, replacement in conditions_other if condition(i)]
[replacement for condition, replacement in conditions_other if condition(248)]
conditions_other
[replacement for condition, replacement in [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']] if condition(248)]
[replacement for condition, replacement in conditions_other if condition(med_data['Quantity'])]
med_data['Quantity']
def standardise_cargo_size3(i):
[replacement for condition, replacement in conditions_other if condition(med_data['Quantity'])]
condition(med_data['Quantity'])
replacement for condition, replacement in conditions_other if condition(med_data['Quantity'])
[replacement for condition, replacement in conditions_other for row in condition(med_data['Quantity'])]
[replacement for condition, replacement in conditions_other if condition(1000)]
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
def choose_condition(i):
    if i == 'CPC Blend':
        conditions_cpc
    else:
        conditions_other

choose_condition(med_data['Grade'])
med_data['Grade'
med_data['Grade']
choose_condition('CPC Blend')
def choose_condition(i):
    if i == 'CPC Blend':
        conditions_cpc
    else:
        conditions_other


choose_condition('CPC Blend')
x = choose_condition('CPC Blend')
def choose_condition(i):
    if i == 'CPC Blend':
        conditions_cpc(250)
    else:
        conditions_other

x = choose_condition('CPC Blend')
e
conditions_cpc(250)
def choose_condition(k):
    if i == 'CPC Blend':
        conditions_cpc(250)
    else:
        conditions_other

conditions_cpc(250)
conditions_cpc = [(lambda i: i < 500, 330),
                  (lambda i: 500 <= i < 600, 535),
                  (lambda i: 600 <= i < 720, 670),
                  (lambda i: 720 <= i <= 760, 760)]
els
conditions_cpc(250)
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
[conditions_cpc(250) if row == 'CPC BLEND' else conditions_other(250) for row in med_data['Grade']]
[replacement for function, replacement in conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade'] if function(i)]
[replacement for condition, replacement in 
       [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']] if condition(250)]
[conditions_cpc if row == 'CPC BLEND' else conditions_other(250) for row in med_data['Grade']]
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
[x for x in [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]
[x[1] for x in [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]
[x[0] for x in [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]
[x[0] for x in 
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
[function, replacement for x in [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]
[x(i) for x in [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]
[x(2520) for x in [conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]]
conditions_other[0]
[conditions_cpc if row == 'CPC BLEND' else conditions_other for row in med_data['Grade']]
return replacement if condition(i) else i for condition, replacement in conditions_cpc
def apply_condition(quantity, grade):
    if grade == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(quantity):
                return replacement
    else:
        for condition, replacement in conditions_other:
            if condition(quantity):
                return replacement

apply_condition(250, 'x')
apply_condition(med_data['Quantity'], med_data['Grade'])
for row in med_data:
    apply_condition(med_data['Quantity'], med_data['Grade'])

def apply_condition(df):
    if df['Grade'] == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(df['Quantity']):
                return replacement
    else:
        for condition, replacement in conditions_other:
            if condition(df['Quantity']):
                return replacement

def apply_condition(df):
    if df['Grade'] == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(df['Quantity']):
                return replacement
    else:
        for condition, replacement in conditions_other:
            if condition(df['Quantity']):
                return replacement

apply_condition(med_data)
condition(df['Quantity'])
for condition, replacement in conditions_cpc:
    if condition(df['Quantity']):
        return replacement

for condition, replacement in conditions_cpc:
    if condition(df['Quantity']):

if df['Grade'] == 'CPC Blend':
    for condition, replacement in conditions_cpc:
        if condition(df['Quantity']):
            return replacement
else:
    for condition, replacement in conditions_other:
        if condition(df['Quantity']):
            return replacement

if df['Grade'] == 'CPC Blend':
    for condition, replacement in conditions_cpc:
        if condition(df['Quantity']):
            return replacement

if df['Grade'] == 'CPC Blend':
    for condition, replacement in conditions_cpc:
        if condition(df['Quantity']):
    return replacement
else:
    for condition, replacement in conditions_other:
        if condition(df['Quantity']):
    return replacement

new_df = pd.concat([med_data['Quantity'], med_data['Grade']])

def apply_condition(df):
    if df['Grade'] == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(df['Quantity']):
                return replacement

if df['Grade'] == 'CPC Blend':
    for condition, replacement in conditions_cpc:
        if condition(df['Quantity']):
            return replacement

if med_data['Grade'] == 'CPC Blend':
    for condition, replacement in conditions_cpc:
        if condition(med_data['Quantity']):
            return replacement

def apply_condition(df):
    if med_data['Grade'] == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(med_data['Quantity']):
                return replacement
    else:
        for condition, replacement in conditions_other:
            if condition(df['Quantity']):
                return replacement
    return df['Quantity']

apply_condition(med_data)
def apply_condition(df):
    if med_data['Grade'] == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(med_data['Quantity']):
                return replacement

def apply_condition(df):
    if df['Grade'] == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(med_data['Quantity']):
                return df['replacement']
    else:
        for condition, replacement in conditions_other:
            if condition(df['Quantity']):
                return df['replacement']
    return df['Quantity']

apply_condition(med_data)
med_data['Quantity'
med_data['Quantity']
df['Grade']
apply_condition(med_data)
def apply_condition(df):
    if df['Grade'] == 'CPC Blend':
        for condition, replacement in conditions_cpc:
            if condition(df['Quantity']):
                return df['replacement'].all()
    else:
        for condition, replacement in conditions_other:
            if condition(df['Quantity']):
                return df['replacement'].all()
    return df['Quantity'].all()


apply_condition(med_data)
apply_condition(med_data).all()
def cond_other(i):
    if i < 300:
        return 250

cond_other(300)
cond_other(100)
def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    else i > 1200:
        return 2050

def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    elif i > 1200:
        return 2050
    else:
        print('error')

def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    elif i > 1200:
        return 2050
    else:
        print('error')


med_data['Quantity'].apply(cond_other)
def cond_cpc(i):
    if i < 500:
        return 330
    elif 500 <= i  < 600:
        return 535
    elif 600 <= i < 720:
        return 670
    elif 720 <= i < 760:
        return 760
    else:
        print('error')

print(grade_list)
def cond_cpc(i):
    if i < 500:
        return 330
    elif 500 <= i  < 600:
        return 535
    elif 600 <= i < 720:
        return 670
    elif 720 <= i < 760:
        return 760
    else:
        print('error')


def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    elif i > 1200:
        return 2050
    else:
        print('error')


def standardize_cargos(cargo):
    if cargo['Grade'] == 'CPC BLEND':
        return cond_cpc(cargo['Quantity'])
    else:
        return cond_other(cargo['Quantity'])

med_data['Quantity'].apply(standardize_cargos, axis=1)
med_data['Quantity'].apply(standardize_cargos)
med_data.apply(standardize_cargos, axis=1)
def cond_cpc(i):
    if i < 500:
        return 330
    elif 500 <= i  < 600:
        return 535
    elif 600 <= i < 720:
        return 670
    elif 720 <= i < 760:
        return 760
    else:
        print('error')


def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    elif i > 1200:
        return 2050
    else:
        print('error')


def standardize_cargos(cargo):
    if cargo['Grade'] == 'CPC BLEND':
        return cond_cpc(cargo['Quantity'])
    else:
        return cond_other(cargo['Quantity'])



med_data.apply(standardize_cargos, axis=1)
def cond_cpc(i):
    if i < 500:
        return 330
    elif 500 <= i  < 600:
        return 535
    elif 600 <= i < 720:
        return 670
    elif 720 <= i < 760:
        return 760



def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    elif i > 1200:
        return 2050



def standardize_cargos(cargo):
    if cargo['Grade'] == 'CPC BLEND':
        return cond_cpc(cargo['Quantity'])
    else:
        return cond_other(cargo['Quantity'])



med_data.apply(standardize_cargos, axis=1)
def cond_cpc(i):
    if i < 500:
        return 330
    elif 500 <= i  < 600:
        return 535
    elif 600 <= i < 720:
        return 670
    elif 720 <= i < 760:
        return 760



def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    elif i > 1200:
        return 2050



def standardize_cargos(cargo):
    if cargo['Grade'] == 'CPC BLEND':
        return cond_cpc(cargo['Quantity'])
    else:
        return cond_other(cargo['Quantity'])



med_data['converted'] = med_data.apply(standardize_cargos, axis=1)
quantities = pd.concat([med_data['Grade'], med_data['Quantity'], med_data['converted'])
quantities = pd.concat([med_data['Grade'], med_data['Quantity'], med_data['converted']])
quantities = pd.concat([med_data['Grade'], med_data['Quantity'], med_data['converted']], axis = 1)
def cond_cpc(i):
    if i < 500:
        return 330
    elif 500 <= i  < 600:
        return 535
    elif 600 <= i < 720:
        return 670
    elif 720 <= i < 760:
        return 760
    else:
        return i



def cond_other(i):
    if i < 300:
        return 250
    elif 300 <= i  < 400:
        return 315
    elif 400 <= i < 500:
        return 450
    elif 500 <= i < 600:
        return 510
    elif 600 <= i < 700:
        return 630
    elif 700 <= i < 900:
        return 750
    elif 900 <= i <= 1200:
        return 1020
    elif i > 1200:
        return 2050
    else:
        return i



def standardize_cargos(cargo):
    if cargo['Grade'] == 'CPC BLEND':
        return cond_cpc(cargo['Quantity'])
    else:
        return cond_other(cargo['Quantity'])



med_data['converted'] = med_data.apply(standardize_cargos, axis=1)

quantities = pd.concat([med_data['Grade'], med_data['Quantity'], med_data['converted']], axis = 1)
print(grade_list)
grade_list = list(med_data['Grade'].unique())
TARGO_DATA = pd.read_excel('L:\TRADING\ANALYSIS\BALANCES\NWE BALANCE.xlsm', sheetname = 'TARGO Stems')
TARGO_DATA = pd.read_excel('L://TRADING//ANALYSIS//BALANCES//NWE BALANCE.xlsm', sheetname = 'TARGO Stems')
cpc_load = TARGO_DATA[TARGO_DATA['Grade'] == 'CPC Blend']['Load Point']
cpc_load = TARGO_DATA[TARGO_DATA['Grade'] == 'CPC Blend']['LoadPoint']
cpc_load = TARGO_DATA[TARGO_DATA['Grade'] == 'CPC Blend']['LoadPoint'].unique()
cpc_load = TARGO_DATA[TARGO_DATA['Grade'] == 'CPC Blend']['LoadPoint'].unique().tolist()
for grade in TARGO_DATA['Grade']:
    load_Ports = TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique().tolist()
    return load_ports

for grade in TARGO_DATA['Grade']:
    load_Ports = TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique().tolist()

return load_ports
for grade in list(med_data['Grade'].unique()):
    load_ports = TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique().tolist()

return load_ports
load_ports =[]
for grade in list(med_data['Grade'].unique()):
    load_port.append(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique().tolist())

return load_ports
load_ports =[]
for grade in list(med_data['Grade'].unique()):
    load_ports.append(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique().tolist())

return load_ports
load_ports =[]
for grade in list(med_data['Grade'].unique()):
    load_ports.append(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique().tolist())
    return load_ports

load_ports =[]
for grade in list(med_data['Grade'].unique()):
    load_ports.append(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique().tolist())


list(med_data['Grade'].unique())
load_ports =[]
for grade in list(med_data['Grade'].unique()):
    load_ports.append(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'])

TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique
(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint']).unique
TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint']
TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()
TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique().dropna()
TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique.dropna()
TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique
unique(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'])
pd.dataframe(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna(
pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna()
for grade in list(med_data['Grade'].unique()):
    for i in pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna():
        df['Grade'] = grade
        df['LoadPoint'] = i

for grade in list(med_data['Grade'].unique()):
    df = pd.Dataframe(columns=['Grade','LoadPoint'])
    for i in pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna():
        df['Grade'] = grade
        df['LoadPoint'] = i

df = pd.Dataframe(columns=['Grade','LoadPoint'])
import pandas as pd
import numpy as np
df = pd.Dataframe(columns=['Grade','LoadPoint'])
for grade in list(med_data['Grade'].unique()):
    df = pd.DataFrame(columns=['Grade','LoadPoint'])
    for i in pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna():
        df['Grade'] = grade
        df['LoadPoint'] = i

pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna()
for i in pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna():
    df['Grade'] = grade
    df['LoadPoint'] = i

for i in pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna():
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i

df = pd.DataFrame(columns=['Grade','LoadPoint'])
for i in pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna():
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i

pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna()
for i in pd.DataFrame(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna():
    print(i)

TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint']
TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique().dropna()
ist(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna()
list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()).dropna()
list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique(
list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    print(i)

for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i

df['Grade'] 
df = pd.DataFrame(columns=['Grade','LoadPoint'])
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i

list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
df = pd.DataFrame([])
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i

return df
df = pd.DataFrame([])
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i
    return df

for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i
        return df

for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i
    return df

for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i

return df
for grade in list(med_data['Grade'].unique()):
    df = pd.DataFrame([])
    for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
        df['Grade'] = 'AZERI'
        df['LoadPoint'] = i
        return df

df = pd.DataFrame([])
df['Grade'] = 'AZERI'
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'] = 'AZERI'
    df['LoadPoint'] = i

df = pd.DataFrame([])
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'].append('AZERI')
    df['LoadPoint'].append(i)

df = pd.DataFrame(['Grade','LoadPoint'])
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'].append('AZERI')
    df['LoadPoint'].append(i)

df = pd.DataFrame(['Grade','LoadPoint'])
df = pd.DataFrame(column=['Grade','LoadPoint'])
df = pd.DataFrame(columns=['Grade','LoadPoint'])
df = pd.DataFrame(columns=['Grade','LoadPoint'])
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    df['Grade'].append('AZERI')
    df['LoadPoint'].append(i)

list(med_data['Grade'].unique())
list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    print(i)

for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    print(i)
    df['Grade'] = i

df['Grade']
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    print(i)
    df['Grade'].append(i)

ist(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    print(i)
    load_ports.append(i)

load_ports =[]
for i in list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique()):
    print(i)
    load_ports.append(i)

list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
r port in UniquePortsForGrade:
    load_ports.append(zip('Grade',port))
for port in UniquePortsForGrade:
    load_ports.append(zip('Grade',port))

UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for port in UniquePortsForGrade:
    load_ports.append(zip('Grade',port))

load_ports =[]
UniquePortsForGrade
port
load_ports =[]
UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for port in UniquePortsForGrade:
    load_ports.append(zip('Grade',port))

UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for port in UniquePortsForGrade:
    load_ports.append(zip(['Grade'],port))

UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for port in UniquePortsForGrade:
    load_ports.append(['Grade',port])

load_ports =[]
UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == 'AZERI']['LoadPoint'].unique())
for port in UniquePortsForGrade:
    load_ports.append(['Grade',port])

med_data['Grade'].dropna().unique()
load_ports =[]
for grade in list(med_data['Grade'].dropna().unique()):
    #df = pd.DataFrame(columns=['Grade','LoadPoint'])
    UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique())
    for port in UniquePortsForGrade:
        load_ports.append(['Grade',port])

load_ports =[]
for grade in list(med_data['Grade'].dropna().unique()):
    #df = pd.DataFrame(columns=['Grade','LoadPoint'])
    UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique())
    for port in UniquePortsForGrade:
        load_ports.append(['Grade',port])

load_ports =[]
for grade in list(med_data['Grade'].dropna().unique()):
    #df = pd.DataFrame(columns=['Grade','LoadPoint'])
    UniquePortsForGrade = list(TARGO_DATA[TARGO_DATA['Grade'] == grade]['LoadPoint'].unique())
    for port in UniquePortsForGrade:
        load_ports.append([grade,port])

list(med_data['Grade'].dropna().unique()
med_data['LoadPoints']
load_port == nan
import mysql
import pypyodbc
import pypyodbc

connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=IEAData;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')
connection.close()
import pypyodbc

connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=IEAData;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')

cursor = connection.cursor()

cursor.execute("""
               SELECT Supply.Country, Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
               """)



connection.close()
tables = cursor.fetchall()
import pypyodbc

connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=IEAData;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')

cursor = connection.cursor()

cursor.execute("""
               SELECT Supply.Country, Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
               """)

tables = cursor.fetchall()
print(tables)
IEA_test_list = []
for row in tables:
    IEA_test_list.append({'Country':row.Country, 'Product':row.Product, 'Period':row.Period, 'Asof':row.Asof, 'PeriodType':row.PeriodType})

IEAtest = pd.DataFrame(IEA_test_list)
import pypyodbc
import pandas as pd

connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=IEAData;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')

cursor = connection.cursor()

cursor.execute("""
               SELECT Supply.Country, Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
               """)

tables = cursor.fetchall()

IEA_test_list = []
for row in tables:
    print(row.Country)

for row in tables:
    print(row)

for row in tables:
    print(row.Supply.Country)

connection.close()
import pypyodbc
import pandas as pd

connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=IEAData;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')

cursor = connection.cursor()

cursor.execute("""
               SELECT Supply.Country [Country], Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
               """)

tables = cursor.fetchall()
for row in tables:
    print(row.Country)

for row in tables:
    print(row)
    dtype(row)

for row in tables:
    print(row.dtype)

for row in tables:
    print(row)

query = """
               SELECT Supply.Country [Country], Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
query = """
               SELECT Supply.Country [Country], Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
               """
connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=IEAData;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')
pdtable = pd.read_sql(query, connection)
query = """
               SELECT Supply.Country, Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
               """
pdtable = pd.read_sql(query, connection)
import pypyodbc
import pandas as pd

iea_connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=IEAData;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')

jodi_connection = pypyodbc.connect('Driver=SQL Server Native Client 11.0;'
                                'Server=STUKLS022;'
                                'Database=JodiOil;'
                                'uid=gami;'
                                'Trusted_Connection=Yes;')
iea_query = """
               SELECT Supply.Country, Supply.Product, Supply.Period, Supply.Quantity, Supply.Asof, Supply.PeriodType
               FROM IEAData.dbo.Supply Supply
               WHERE (Supply.Country In ('USA')) 
               AND Supply.PeriodType = 'MTH'
               AND Supply.Asof = (Select MAX(Asof) FROM  IEAData.dbo.Supply)
               AND Supply.Product IN ('CRUDE', 'COND')
               AND Period >= '1-jan-14'
               ORDER BY Supply.Country
               """

jodi_query = """
               SELECT Countries.Country, PrimaryTable.Product, WorldPrimaryFLows.Description, PrimaryTable.Unit, CONVERT(datetime, CONCAT(PrimaryTable.Month,'-01'), 121) as Month, PrimaryTable.Quantity, PrimaryTable.StatusCode
               FROM JodiOil.dbo.PrimaryTable PrimaryTable 
               INNER JOIN JodiOil.dbo.Countries Countries ON PrimaryTable.Country = Countries.[Country Code]
               INNER JOIN JodiOil.dbo.WorldPrimaryFLows WorldPrimaryFLows ON PrimaryTable.Flow = WorldPrimaryFLows.[Code]
               """               


iea_table = pd.read_sql(iea_query, iea_connection)
jodi_table = pd.read_sql(jodi_query, jodi_connection)
print(jodi_table.head())
list(jodi_table['description'].unique())
iea_query = """
                SELECT CrudeData.Country, CrudeData.Product, CrudeData.Balance, CrudeData.Period, CrudeData.Quantity, CrudeData.Asof, CrudeData.PeriodType
                FROM IEAData.dbo.CrudeData CrudeData
                ORDER BY CrudeData.Country
                """
iea_table = pd.read_sql(iea_query, iea_connection)
list(iea_table['country'].unique())
iea_query = """
                SELECT CrudeData.Country, CrudeData.Product, Balance.Desc, CrudeData.Period, CrudeData.Quantity, CrudeData.Asof, CrudeData.PeriodType
                FROM IEAData.dbo.CrudeData CrudeData
                INNER JOIN IEAData.dbo.Balance Balance ON CrudeData.Balance = Balance.Flow
                ORDER BY CrudeData.Country
                """
iea_table = pd.read_sql(iea_query, iea_connection)
iea_query = """
                SELECT CrudeData.Country, CrudeData.Product, Balance.[Desc], CrudeData.Period, CrudeData.Quantity, CrudeData.Asof, CrudeData.PeriodType
                FROM IEAData.dbo.CrudeData CrudeData
                INNER JOIN IEAData.dbo.Balance Balance ON CrudeData.Balance = Balance.Flow
                ORDER BY CrudeData.Country
                """
iea_table = pd.read_sql(iea_query, iea_connection)
list(jodi_table['description'].unique())
list(jodi_table['Country'].unique())
list(jodi_table['country'].unique())
len(list(jodi_table['country'].unique()))
jodi_pivot = pd.pivot_table(jodi_table, values = 'quantity', index = 'month', columns = 'countries')
jodi_pivot = pd.pivot_table(jodi_table, values = 'quantity', index = 'month', columns = 'country')
jodi_table_kbbl = jodi_table[jodi_table['unit'] == 'KBBL']
jodi_pivot = pd.pivot_table(jodi_table_kbbl, values = 'quantity', index = 'month', columns = 'description')
jodi_pivot = pd.pivot_table(jodi_table_kbbl, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_table_kbd = jodi_table[jodi_table['unit'] == 'KBD']
jodi_pivot = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_table_kbbl = jodi_table[jodi_table['unit'] == 'KBBL']
jodi_table_kbd = jodi_table[jodi_table['unit'] == 'KBD']


jodi_pivot_kbbl = pd.pivot_table(jodi_table_kbbl, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
list(jodi_table['month'].unique())
jodi_table_kbd['month'].strftime('%m/%d/%Y')
jodi_table_kbd['month'].dt.strftime('%m/%d/%Y')
jodi_table_kbd_0809 = jodi_table_kbd['01/01/2010' < jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009']
jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009'
jodi_table_kbd_0809 = jodi_table_kbd['01/01/2010' > jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009']
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009') & (jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') < '01/01/2010')]
jodi_table_kbd['month'].dt.strftime('%m/%d/%Y')
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009')]
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009') & (jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') < '01/01/2010')]
(jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009')
jodi_table_kbd['month'].dt.strftime('%m/%d/%Y')
(jodi_table_kbd['month'].dt.strftime('%m/%d/%Y') > '01/01/2009')
jodi_table_kbd['month'].dt.strftime('%Y/%m/%d') > '01/01/2009'
jodi_table_kbd['month'].dt.strftime('%Y/%m/%d')
jodi_table_kbd['month'].dt.strftime('%m/%d/%Y')
from datetime import datetime
(jodi_table_kbd['month'] > datetime(2013, 1, 1))
(jodi_table_kbd['month'] > datetime(2013, 15, 1))
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'] > datetime(2009, 1, 1)) & (jodi_table_kbd['month'] < datetime(2011, 1, 1))]
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'] > datetime(2009, 1, 1)) &
                                     (jodi_table_kbd['month'] < datetime(2011, 1, 1)) &
                                     (jodi_table_kbd['product'] == 'TOTCRUDE')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = ['description','country'], aggfunc='sum')
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'] > datetime(2009, 11, 1)) &
                                     (jodi_table_kbd['month'] < datetime(2010, 2, 1)) &
                                     (jodi_table_kbd['product'] == 'TOTCRUDE')
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'] > datetime(2009, 11, 1)) &
                                     (jodi_table_kbd['month'] < datetime(2010, 2, 1)) &
                                     (jodi_table_kbd['product'] == 'TOTCRUDE')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = ['description','country'], aggfunc='sum')
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_0809, values = 'quantity', index = 'month', columns = ['description','country'], aggfunc='sum')
list(jodi_table['description'].unique())
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'] > datetime(2009, 11, 1)) &
                                     (jodi_table_kbd['month'] < datetime(2010, 2, 1)) &
                                     (jodi_table_kbd['product'] == 'TOTCRUDE') &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_0809, values = 'quantity', index = 'month', columns = ['description','country'], aggfunc='sum')
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_0809.dropna(axis=0), values = 'quantity', index = 'month', columns = ['description','country'], aggfunc='sum')
jodi_table_kbd_0809
jodi_table_kbd_0809.dropna(axis=0)
jodi_table_kbd_0809.dropna(axis=1)
jodi_table_kbd_0809.dropna(axis=1, how='all')
jodi_table_kbd_0809_nozeros = jodi_table_kbd_0809.loc[(jodi_table_kbd_0809 != 0)]
jodi_table_kbd_0809_nozeros = jodi_table_kbd_0809.loc[(jodi_table_kbd_0809 != 0).all(axis=1), :]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_0809_nozeros, values = 'quantity', index = 'month', columns = ['description','country'], aggfunc='sum')
jodi_table_kbd_0809 = jodi_table_kbd[(jodi_table_kbd['month'] > datetime(2007, 11, 1)) &
                                     (jodi_table_kbd['month'] < datetime(2012, 2, 1)) &
                                     (jodi_table_kbd['product'] == 'TOTCRUDE') &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_0809, values = 'quantity', index = 'month', columns = ['description'], aggfunc='sum')
jodi_table_kbd_final = jodi_table_kbd[(jodi_table_kbd['product'] == 'TOTCRUDE') &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_final, values = 'quantity', index = 'month', columns = ['description'], aggfunc='sum')
list(jodi_table['description'].unique())
jodi_table = pd.read_sql(jodi_query, jodi_connection)
jodi_table_kbd = jodi_table[jodi_table['unit'] == 'KBD']
list(jodi_table['product'].unique())
jodi_table['product']
jodi_table_kbd_final = jodi_table_kbd[(jodi_table_kbd['product'] == 'TOTCRUDE') &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_table_kbbl_final = jodi_table_kbbl[(jodi_table_kbbl['product'] == 'TOTCRUDE') &
                                     (jodi_table_kbbl['description'] == 'Crude Prodction')
                                     ]
jodi_table_kbd_final = jodi_table_kbd[(jodi_table_kbd['product'] == 'CRUDEOIL') &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
jodi_table_kbd_final = jodi_table_kbd[(jodi_table_kbd['product'] == 'CRUDEOIL') &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_final, values = 'quantity', index = 'month', columns = ['description'], aggfunc='sum')
list(jodi_table['product'].unique())
jodi_table_kbd_final = jodi_table_kbd[((jodi_table_kbd['product'] == 'CRUDEOIL') |
                                      (jodi_table_kbd['product'] == 'OTHERCRUDE'))
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_table_kbd_final = jodi_table_kbd[((jodi_table_kbd['product'] == 'CRUDEOIL') |
                                      (jodi_table_kbd['product'] == 'OTHERCRUDE')) &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_final, values = 'quantity', index = 'month', columns = ['description'], aggfunc='sum')
jodi_table_kbd_final = jodi_table_kbd[(jodi_table_kbd['product'].isin(['CRUDEOIL','OTHERCRUDE'])) &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_final, values = 'quantity', index = 'month', columns = ['description'], aggfunc='sum')
jodi_table_kbd_final = jodi_table_kbd[(jodi_table_kbd['product'].isin(['CRUDEOIL','OTHERCRUDE','NGL'])) &
                                     (jodi_table_kbd['description'] == 'Crude Prodction')
                                     ]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd_final, values = 'quantity', index = 'month', columns = ['description'], aggfunc='sum')
jodi_table[jodi_table['country'] == 'CHINA']
list(jodi_table['product'].unique())
jodi_connection.close()
iea_connection.close()
jodi_table_kbd = jodi_table[(jodi_table['unit'] == 'KBD') & (jodi_table['product'].isin(['CRUDEOIL','OTHERCRUDE','NGL']))]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_table_kbbl = jodi_table[(jodi_table['unit'] == 'KBBL') & (jodi_table['product'].isin(['CRUDEOIL','OTHERCRUDE','NGL']))]

jodi_table_kbd = jodi_table[(jodi_table['unit'] == 'KBD') & (jodi_table['product'].isin(['CRUDEOIL','OTHERCRUDE','NGL']))]
jodi_table_kbbl = jodi_table[(jodi_table['unit'] == 'KBBL') & (jodi_table['product'].isin(['CRUDEOIL','OTHERCRUDE','NGL']))]
jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_pivot_kbbl = pd.pivot_table(jodi_table_kbbl, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_table_kbbl
list(jodi_table['product'].unique())
list(jodi_table['description'].unique())
jodi_table_kbbl = jodi_table[(jodi_table['unit'] == 'KBBL') & (jodi_table['product'].isin(['CRUDEOIL','OTHERCRUDE']))]

jodi_table_kbd = jodi_table[(jodi_table['unit'] == 'KBD') & (jodi_table['product'].isin(['CRUDEOIL','OTHERCRUDE']))]

jodi_pivot_kbd = pd.pivot_table(jodi_table_kbd, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
jodi_pivot_kbbl = pd.pivot_table(jodi_table_kbbl, values = 'quantity', index = 'month', columns = 'description', aggfunc='sum')
world_sd = pd.concat([jodi_pivot_kbd[['Crude Prodction',
                                      'Refinery Runs',
                                      'Exports',
                                      'Imports',
                                      'Other sources',
                                      'Statistical Difference',
                                      'Products Transferred/Backfloes',
                                      'Direct Use']], 
                jodi_pivot_kbbl[['Closing Stock Level','Stock Change']]], ignore_index=False)
world_sd = pd.concat([jodi_pivot_kbd[['Crude Prodction',
                                      'Refinery Runs',
                                      'Exports',
                                      'Imports',
                                      'Other sources',
                                      'Statistical Difference',
                                      'Products Transferred/Backfloes',
                                      'Direct Use']], 
                jodi_pivot_kbbl[['Closing Stock Level','Stock Change']]], ignore_index=True)
world_sd = pd.concat([jodi_pivot_kbd[['Crude Prodction',
                                      'Refinery Runs',
                                      'Exports',
                                      'Imports',
                                      'Other sources',
                                      'Statistical Difference',
                                      'Products Transferred/Backfloes',
                                      'Direct Use']], 
                jodi_pivot_kbbl[['Closing Stock Level','Stock Change']]], axis=0)
world_sd = pd.concat([jodi_pivot_kbd[['Crude Prodction',
                                      'Refinery Runs',
                                      'Exports',
                                      'Imports',
                                      'Other sources',
                                      'Statistical Difference',
                                      'Products Transferred/Backfloes',
                                      'Direct Use']], 
                jodi_pivot_kbbl[['Closing Stock Level','Stock Change']]], axis=1)